/*
 *
 * Copyright (C) 1999-2018 McAfee, LLC.  All rights reserved.
 * 
 * This example gets the file extensions which the engine will look at
 * during a scan and displays them on stdout. No scanning is performed
 * in this example.
 *
 * 
 */

#include "avengine.h"   /* For engine definitions */
#include "avparam.h"    /* For paramater manipulation macros/functions */

#ifdef NETWARE
#include <process.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* Functions prototypes for this example */
AV_ERROR InitialiseEngine(AV_INITRESULT *);
void BuildParameterList(AV_PARAMETERS *);
void DisplayExtensions(const char *, AV_EXTENSIONLIST *);
void DisplayExtensionLists(AV_INITRESULT *);

/* Callback function */
AV_LIBRET LIBFUNC API_Callback(HSCANNER, AV_MESSAGE, AV_PARAM1, AV_PARAM2 );

#if defined UNIX
#define ENGINE_DIRECTORY "../lib"
#define AV_NAMES "../dat/avvnames.dat"
#define AV_SCAN "../dat/avvscan.dat"
#define AV_CLEAN "../dat/avvclean.dat"
#else
#define ENGINE_DIRECTORY "..\\bin"
#define AV_NAMES "..\\dat\\avvnames.dat"
#define AV_SCAN "..\\dat\\avvscan.dat"
#define AV_CLEAN "..\\dat\\avvclean.dat"
#endif

/* The maximum number of parameters we will use to initialize the engine */
#define AV_MAX_INIT_PARAMS 10




/* Function to build engine initialization parameters
 * and initialize the engine. This assumes init_result
 * has been allocated and initialised.
 */
AV_ERROR InitialiseEngine(AV_INITRESULT *init_result)
{
    AV_PARAMETERS init_params;
    AV_SINGLEPARAMETER parameters[AV_MAX_INIT_PARAMS];
    AV_ERROR error;

    AV_DATSETFILES av_dat_set;

    const char *av_dat_names[3];

    av_dat_names[0] = AV_NAMES;
    av_dat_names[1] = AV_SCAN;
    av_dat_names[2] = AV_CLEAN;


    /* Initialize all structures */
    memset(&init_params, 0, sizeof(AV_PARAMETERS));
    init_params.structure_size = sizeof(AV_PARAMETERS);
    
    init_params.parameters = parameters;
    
    /* Add a callback function */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );

    memset(&av_dat_set, 0, sizeof(AV_DATSETFILES));
    av_dat_set.structure_size = sizeof(AV_DATSETFILES);
    av_dat_set.read_type = AV_READTYPE_DIRECT;
    av_dat_set.datfile_count = 3;
    av_dat_set.datfiles.datfile_names = av_dat_names;

    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_VIRUSDATSET,
                    (void *)&av_dat_set,
                    sizeof(AV_DATSETFILES));

    /* Tell the engine the location of the engine binaries */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_ENGINELOCATION,
                    (void *)ENGINE_DIRECTORY,
                    ( strlen(ENGINE_DIRECTORY) + 1 )
                    );

    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_APIVER,
                    (void *)AV_APIVER,
                    sizeof(void *)
                    );

    /* Then initialize */
    error = AVInitialise(&init_params,init_result);
    
    return error;
}


/* Function to determine whether any extensions contains
 * wildcards, add wildcard characters if necessary and
 * to display the extensions in the list. Extensions are
 * displayed in columns of 10.
 */
void DisplayExtensions(const char *string, AV_EXTENSIONLIST *list)
{
    WORD extcount = 0;
    char extension[AV_MAXEXT_LEN];
    
    printf("%s\n    ", string);
    
    while(extcount < list->nextensions)
    {
        int columncount;
        
        /* Display the extensions in columns of 10 */
        for(columncount = 0;columncount < 10 && extcount < list->nextensions;columncount++)
        {
            /* Copy the extension into our local variable. Use memcpy because
             * it may have NULL characters in if it contains wildcards.
             */
            memcpy(extension, list->extensions[extcount].extension, AV_MAXEXT_LEN);
        
            /* Need to look at the mask and work out what is
             * a wildcard and what is a character. Display
             * wildcards as ?. For more information on how
             * the mask and extension works, see the reference
             * to AVP_USEREXTENSIONS in the API manual.
             */
            if((list->extensions[extcount].mask & 0x000000ff) == 0)
                extension[0] = '?';

            if((list->extensions[extcount].mask & 0x0000ff00) == 0)
                extension[1] = '?';

            if((list->extensions[extcount].mask & 0x00ff0000) == 0)
                extension[2] = '?';

            extension[3] = '\0';
            
            printf("%s ", extension);
            extcount++;
        }
        printf("\n    ");
    }
    
    printf("\n");
    
}

/* Function to get all file extensions from the engine.
 * Uses both RetrieveExtensionLists and
 * RetrieveSingleExtensionList functions.
 */
void DisplayExtensionList(AV_EXTENSIONINFO *ext_info)
{
    const char *message = NULL;
    
    switch(ext_info->list_type)
    {
        case AV_EXTLIST_EXE:
        {
            message = "Extensions for executable files";
            break;
        }
        
        case AV_EXTLIST_MACRO:
        {
            message = "Extensions for files containing macros";
            break;
        }
        
        case AV_EXTLIST_COMPRESSEDEXE:
        {
            message = "Extensions for compressed files";
            break;
        }
        
        case AV_EXTLIST_ARCHIVE:
        {
            message = "Extensions for archive files";
            break;
        }
        
        case AV_EXTLIST_ALL:
        {
            message = "All extensions engine scans for";
            break;
        }
    }

    if (message != NULL)
    {
        DisplayExtensions(message, &ext_info->list);
    }
}

#define AV_MAX_PARAMS 10

void GetExtensions(AV_INITRESULT *init_result)
{
    AV_PARAMETERS parameters;
    AV_SINGLEPARAMETER params[AV_MAX_PARAMS];
    
    size_t i;
    
    static AV_EXTLISTTYPE extTypes[] = { AV_EXTLIST_EXE, AV_EXTLIST_ARCHIVE, AV_EXTLIST_COMPRESSEDEXE, AV_EXTLIST_MACRO, AV_EXTLIST_ALL };
    static size_t nTypes = sizeof(extTypes) / sizeof(AV_EXTLISTTYPE);
    
    memset(&parameters, 0, sizeof(AV_PARAMETERS));
    parameters.structure_size = sizeof(AV_PARAMETERS);
    parameters.parameters = params;

    AVAddParameter( parameters.parameters,
                    parameters.nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );

    AVAddBoolParameter( parameters.parameters,
                        parameters.nparameters,
                        AVP_EXTENSIONINFO);

    for (i = 0; i < nTypes; i++)
    {
        AV_ERROR error;

        AVAddParameter( parameters.parameters,
                        parameters.nparameters,
                        AVP_EXTENSIONLIST,
                        (void *)(DWORD)( extTypes[i] ),
                        sizeof(void *)
                        );
        
        error = AVRetrieveInstanceInfo(init_result->engine_handle, &parameters);
        if (error != AVE_SUCCESS)
            printf("AVRetrieveInstanceInfo failed (error: %d)\n", (int)error);
        
        AVDeleteParameter(&parameters, AVP_EXTENSIONLIST, 0);
    }
}

int main(int argc ,char *argv[])
{
    /* Structure to contain initialization results */
    AV_INITRESULT init_result;
    
    AV_ERROR error;
    
    printf("Demo application for anti-virus engine\n");
    
    
    #if defined NETWARE
    /* If on netware, register the engine with the OS */
    if (AVNLMRegister() != 0)
    {
        printf("Failed to register the engine.\n");
        return 1;
    }
    #endif
    
    /* Initialise initialisation structures. */
    memset(&init_result, 0, sizeof(AV_INITRESULT));
    init_result.structure_size = sizeof(AV_INITRESULT);
    
    /* Initialise the engine */
    error = InitialiseEngine(&init_result);
    if (error != AVE_SUCCESS)
    {
        printf("Engine failed to initialize (error: %d)\n", (int)error);
        return 1;
    }
    
    /* Display the extension lists */
    GetExtensions(&init_result);
    
    /* Close the engine */
    AVClose(init_result.engine_handle);
    
    return 0;
}


/* Callback function gets messages from the engine and acts upon them ... */

AV_LIBRET LIBFUNC API_Callback(HSCANNER hengine, AV_MESSAGE _message, AV_PARAM1 _p1, AV_PARAM2 _p2)
{
    /* Default return value */
    AV_LIBRET returnvalue = 0;

    /* Not much is needed in the callback function because we
     * are not doing any scanning.
     */
    switch(_message)
    {
        /* Miscellaneous messages */

        /* The extension lists are returned through an
         * AVM_INSTANCEINFO message.
         */
        case AVM_INSTANCEINFO:
        {
            switch (_p1)
            {
                case AVINFO_EXTENSIONLIST:
                {
                    DisplayExtensionList((AV_EXTENSIONINFO *)_p2.pValue);
                    break;
                }
                
                default:
                    break;
            }
            break;
        }
        
        /* Fall-through case */
        default:
            printf("Received message 0x%x p1:0x%x p2:0x%lx\n\r",(unsigned)_message,(unsigned)_p1,(unsigned long)(_p2.dwValue));
            break;
    }

    return returnvalue;
}

