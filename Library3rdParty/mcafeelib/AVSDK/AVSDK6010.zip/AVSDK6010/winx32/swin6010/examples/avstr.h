/*
 *
 * Copyright (C) 2005-2018 McAfee, LLC.  All rights reserved.
 * 
 * String handling functions for engine API.
 *
 * 
 */


#ifndef AV_STR_H
#define AV_STR_H

#include "avtypes.h"

/* Copies filename supplied to the engine DeferredIO request */
#define AVCopyFilename(ioreq, fname) AVSafeCopy(ioreq->io_datapacket.filename, MAXPATH, fname)

/* Copies the extension to the engine DeferredIO request */
#define AVCopyExt(ioreq, fname) AVSafeCopy(ioreq->io_datapacket.filename, AV_MAXEXT_LEN, fname)

/* General purpose function that copies to a destination buffer of size destSize.
 * Returns the number of bytes copied.
 * Guarantees NULL termination. 
 */
size_t AVSafeCopy(char *dest, size_t destSize, const char *src);

#endif

