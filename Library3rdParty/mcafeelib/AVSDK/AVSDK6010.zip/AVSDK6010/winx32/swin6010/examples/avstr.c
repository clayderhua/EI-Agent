/*
 *
 * Copyright (C) 2005-2018 McAfee, LLC.  All rights reserved.
 * 
 * String handling functions for engine API.
 *
 * 
 */

#include "avstr.h"
#include <stdlib.h>
#include <string.h>


/* AVSafeCopy
 *
 * dest     : destination buffer - out
 * destsize : size of destination buffer - in
 * src      : string to copy - in
 */
size_t AVSafeCopy(char *dest, size_t destsize, const char *src)
{
    size_t copy = strlen(src);
    if (copy > (destsize - 1))
    {
        copy = destsize - 1;
    }

    memcpy(dest, src, copy);
    dest[copy] = '\0';

    return copy;
}
