/*
 *
 * Copyright (C) 2005-2018 McAfee, LLC.  All rights reserved.
 * 
 * This example takes each command line argument and passes it to the
 * engine as a file. The file is scanned by the engine, and the results are
 * displayed via the callback function.
 *
 * 
 */

#include "avengine.h"   /* For engine definitions */
#include "avparam.h"    /* For param manipulation macros */

#ifdef NETWARE
#include <process.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>     /* assert() */


/* Functions prototypes for this example */
AV_ERROR InitialiseEngine(AV_INITRESULT *);
void BuildParameterList(AV_PARAMETERS *);

/* Callback function */
AV_LIBRET LIBFUNC API_Callback(HSCANNER, AV_MESSAGE, AV_PARAM1, AV_PARAM2 );

#if defined UNIX
#define ENGINE_DIRECTORY "../lib"
#define AV_NAMES "../dat/avvnames.dat"
#define AV_SCAN "../dat/avvscan.dat"
#define AV_CLEAN "../dat/avvclean.dat"
#else
#define ENGINE_DIRECTORY "..\\bin"
#define AV_NAMES "..\\dat\\avvnames.dat"
#define AV_SCAN "..\\dat\\avvscan.dat"
#define AV_CLEAN "..\\dat\\avvclean.dat"
#endif

/* The maximum number of parameters we will use to initialize the engine */
#define AV_MAX_INIT_PARAMS 10

/* Function to build engine initialization parameters
 * and initialize the engine. This assumes init_result
 * has been allocated and initialised.
 */
AV_ERROR InitialiseEngine(AV_INITRESULT *init_result)
{

    AV_PARAMETERS init_params;
    AV_SINGLEPARAMETER parameters[AV_MAX_INIT_PARAMS];
    AV_ERROR error;

    AV_DATSETFILES av_dat_set;

    const char *av_dat_names[3];

    av_dat_names[0] = AV_NAMES;
    av_dat_names[1] = AV_SCAN;
    av_dat_names[2] = AV_CLEAN;

    memset(&av_dat_set, 0, sizeof(AV_DATSETFILES));
    av_dat_set.structure_size = sizeof(AV_DATSETFILES);
    av_dat_set.read_type = AV_READTYPE_DIRECT;
    av_dat_set.datfile_count = 3;
    av_dat_set.datfiles.datfile_names = av_dat_names;

    /* Initialize all structures */
    memset(&init_params, 0, sizeof(AV_PARAMETERS));
    init_params.structure_size = sizeof(AV_PARAMETERS);
    
    init_params.parameters = parameters;
    
    /* Add a callback function */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );
       
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_VIRUSDATSET,
                    (void *)&av_dat_set,
                    sizeof(AV_DATSETFILES));

    /* Tell the engine the location of the engine binaries */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_ENGINELOCATION,
                    (void *)ENGINE_DIRECTORY,
                    ( strlen(ENGINE_DIRECTORY) + 1 )
                    );

    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_APIVER,
                    (void *)AV_APIVER,
                    sizeof(void *)
                    );

    /* Then initialize */
    error = AVInitialise(&init_params,init_result);
    
    return error;
}


/* Function to add any parameters that the scan needs.
 * It does not add a target to scan.
 */
void BuildParameterList(AV_PARAMETERS *parameters)
{
    /* The callback function */
    AVAddParameter( parameters->parameters,
                    parameters->nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );

    /* Scan for everything */
    AVAddBoolParameter( parameters->parameters,
                        parameters->nparameters,
                        AVP_SCANALLFILES
                        );
}

/* The maximum number of parameters we will use during scanning */
#define AV_MAX_SCAN_PARAMS    20

int main(int argc ,char *argv[])
{
    /* Structure to contain initialization results */
    AV_INITRESULT init_result;
    
    /* Structures used for scanning */
    AV_PARAMETERS scan_parameters;
    AV_SINGLEPARAMETER parameters[AV_MAX_SCAN_PARAMS];
    AV_ERROR error;
    int i; 
    AV_OBJECT object;

    printf("Demo application for anti-virus engine\n");
    
    
    #if defined NETWARE
    /* If on netware, register the engine with the OS */
    if (AVNLMRegister() != 0)
    {
        printf("Failed to register the engine.\n");
        return 1;
    }
    #endif
    
    /* Initialise initialisation structures. */
    memset(&init_result, 0, sizeof(AV_INITRESULT));
    init_result.structure_size = sizeof(AV_INITRESULT);
    
    /* Initialise the engine */
    error = InitialiseEngine(&init_result);
    if (error != AVE_SUCCESS)
    {
        printf("Engine failed to initialize (error: %d)\n", (int)error);
        return 1;
    }

    /* Initialize scanning structures */
    memset(&scan_parameters, 0, sizeof(AV_PARAMETERS));
    scan_parameters.structure_size = sizeof(AV_PARAMETERS);
    scan_parameters.parameters = parameters;
    
    /* Add any parameters needed for scanning. */
    BuildParameterList(&scan_parameters);

    memset(&object, 0, sizeof(AV_OBJECT));
    object.structure_size = sizeof(AV_OBJECT);
    object.pcontext = NULL;

    /* This parameter holds information about scanned object */
    /* It needs to be added to the parameters list only once */
    /*  (we will update the structure pointed to by the parameter instead) */
    AVAddParameter( scan_parameters.parameters,
                    scan_parameters.nparameters,
                    AVP_OBJECT,
                    (void*)&object,
                    sizeof(AV_OBJECT)
                    );

    for(i = 1; i < argc; i++)
    {
        /* Set up the current object to scan */
        object.type = AVOT_FILE;
        /* The path to the file will be provided to the engine */
        object.subtype = AVOS_DOSPATH;
        /* Full path of the file to scan */
        object.pAttribute = (void *)argv[i];
        object.size = (DWORD)strlen(argv[i]) + 1;
               
        /* Start the scan */
        error = AVScanObject(init_result.engine_handle, &scan_parameters, NULL);

        if (error != AVE_SUCCESS)
            printf("Scan failed (error: %d)\n", (int)error);
        
    }
        
    /* Close the engine */
    AVClose(init_result.engine_handle);
    
    return 0;
}


/* Callback function gets messages from the engine and acts upon them ... */

AV_LIBRET LIBFUNC API_Callback(HSCANNER hengine, AV_MESSAGE _message, AV_PARAM1 _p1, AV_PARAM2 _p2)
{
    /* Default return value */
    AV_LIBRET returnvalue = 0;

    switch(_message)
    {
        /* Miscellaneous messages */

        /* Status messages */

        case AVM_OBJECTNAME:
            printf("%s ... ",(const char*)(_p2.pValue));
            break;

        case AVM_OBJECTSIZE:
            printf("[%llu bytes] ", _p2.qwValue);
            break;

        case AVM_OBJECTREPAIRED:
            printf("repaired\n");
            break;

        case AVM_OBJECTNOTSCANNED:
            printf("*not* scanned (error: %lu)\n",(unsigned long)(_p2.dwValue));
            break;

        case AVM_OBJECTSUMMARY:
            if (_p2.dwValue == AV_SUMMARY_OBJECTOK)
                printf("is OK\n");
            break;

        case AVM_OBJECTINFECTED:
            printf("is infected with %s\n",((AV_INFECTION*)_p2.pValue)->virus_name);
            break;

        case AVM_OBJECTCLOSED:
        case AVM_OBJECTSTART:
            break;

        /* Query messages ... */

        case AVM_QUERYTERMINATE:
        case AVM_QUERYDENYSCAN:
        case AVM_QUERYDENYREPAIR:
        case AVM_QUERYQUITSCANNING:
            /* Let them drop through */
            break;

        /* Fall-through case */

        default:
            printf("Received message 0x%x p1:0x%x p2:0x%lx\n\r",(unsigned)_message,(unsigned)_p1,(unsigned long)(_p2.dwValue));
            break;
        
    }

    return returnvalue;
}

