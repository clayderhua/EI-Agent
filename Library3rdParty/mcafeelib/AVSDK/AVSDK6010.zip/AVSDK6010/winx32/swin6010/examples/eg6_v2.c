/*
 *
 * Copyright (C) 2005-2018 McAfee, LLC.  All rights reserved.
 * 
 * This example takes the first command line argument as
 * the registry path to be scanned. An optional -c
 * command line argument allows cleaning to be enabled.
 * A registry scan is performed on that path and if
 * selected the path is cleaned.
 *
 * All Registry IO is performed by the engine.
 * All DAT IO is performed by the engine.
 *
 *
 * 
 */

#ifndef WIN32
#error "This example only works with WIN32."
#endif

#include "avengine.h"   /* For engine definitions */
#include "avparam.h"    /* For param manipulation macros */
#include "avstr.h"      /* For engine API string handling functions */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif
#define _stricmp(a,b)   strcmp((a),(b))

/* Functions prototypes for this example */
AV_ERROR InitialiseEngine(AV_INITRESULT *);

void BuildParameterList(AV_PARAMETERS *, BOOL);

/* Callback function */
AV_LIBRET LIBFUNC API_Callback(HSCANNER, AV_MESSAGE, AV_PARAM1, AV_PARAM2 );

#define ENGINE_DIRECTORY "..\\bin"
#define DIRSEPCHAR '\\'
#define AV_NAMES "..\\dat\\avvnames.dat"
#define AV_SCAN "..\\dat\\avvscan.dat"
#define AV_CLEAN "..\\dat\\avvclean.dat"

/* The maximum number of parameters we will use to initialize the engine */
#define AV_MAX_INIT_PARAMS 10



/* Function to build engine initialization parameters
 * and initialize the engine. This assumes init_result
 * has been allocated and initialised.
 */
AV_ERROR InitialiseEngine(AV_INITRESULT *init_result)
{
    AV_PARAMETERS init_params;
    AV_SINGLEPARAMETER parameters[AV_MAX_INIT_PARAMS];
    AV_ERROR error;

    AV_DATSETFILES av_dat_set;

    const char *av_dat_names[3];

    av_dat_names[0] = AV_NAMES;
    av_dat_names[1] = AV_SCAN;
    av_dat_names[2] = AV_CLEAN;

    memset(&av_dat_set, 0, sizeof(AV_DATSETFILES));
    av_dat_set.structure_size = sizeof(AV_DATSETFILES);
    av_dat_set.read_type = AV_READTYPE_DIRECT;
    av_dat_set.datfile_count = 3;
    av_dat_set.datfiles.datfile_names = av_dat_names;

    /* Initialize all structures */
    memset(&init_params, 0, sizeof(AV_PARAMETERS));
    init_params.structure_size = sizeof(AV_PARAMETERS);
    
    init_params.parameters = parameters;
    
    /* Add a callback function */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );
       
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_VIRUSDATSET,
                    (void *)&av_dat_set,
                    sizeof(AV_DATSETFILES));

    /* Tell the engine the location of the engine binaries */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_ENGINELOCATION,
                    (void *)ENGINE_DIRECTORY,
                    ( strlen(ENGINE_DIRECTORY) + 1 )
                    );

    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_APIVER,
                    (void *)AV_APIVER,
                    sizeof(void *)
                    );

    /* Then initialize */
    error = AVInitialise(&init_params,init_result);
    
    return error;
}

/* Function to add any parameters that the scan needs.
 * It does not add a target to scan.
 */
void BuildParameterList(AV_PARAMETERS *parameters, BOOL clean)
{
    /* The callback function */
    AVAddParameter( parameters->parameters,
                    parameters->nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );

    if (clean != FALSE)
    {
        /* Tell the engine to clean the scanned files */
        AVAddBoolParameter( parameters->parameters,
                            parameters->nparameters,
                            AVP_REPAIR
                            );
    }
}

/* The maximum number of parameters we will use during scanning */
#define AV_MAX_SCAN_PARAMS    20

int main(int argc ,char *argv[])
{
    /* Structure to contain initialization results */
    AV_INITRESULT init_result;
    
    /* Structures used for scanning */
    AV_PARAMETERS scan_parameters;
    AV_SINGLEPARAMETER parameters[AV_MAX_SCAN_PARAMS];
    AV_SCANRESULT scan_result;
    AV_OBJECT av_object;
    
    AV_ERROR error;
    BOOL do_clean = FALSE;
    
    printf("Demo application for anti-virus engine\n");
    printf("Scan a registry entry with optional cleaning.\n");
    
    /* Initialise initialisation structures. */
    memset(&init_result, 0, sizeof(AV_INITRESULT));
    init_result.structure_size = sizeof(AV_INITRESULT);
    
    /* Initialise the engine */
    error = InitialiseEngine(&init_result);
    if (error != AVE_SUCCESS)
    {
        printf("Engine failed to initialize (error: %d)\n", (int)error);
        return 1;
    }
    
    /* Initialize scanning structures */
    memset(&scan_parameters, 0, sizeof(AV_PARAMETERS));
    scan_parameters.structure_size = sizeof(AV_PARAMETERS);
    scan_parameters.parameters = parameters;
    
    memset(&scan_result, 0, sizeof(AV_SCANRESULT));
    scan_result.structure_size = sizeof(AV_SCANRESULT);

    memset(&av_object, 0, sizeof(AV_OBJECT));
    av_object.structure_size = sizeof(AV_OBJECT);
    
    if (argc >= 3)
    {
        if (_stricmp(argv[2], "-c") == 0)
        {
            do_clean = TRUE;
        }
    }

    /* Add any parameters needed for scanning. */
    BuildParameterList(&scan_parameters, do_clean);

    if (argc > 1)
    {

        /* Add a registry target to scan. */
        av_object.type = AVOT_REGISTRY;
        av_object.subtype = AVOS_DOSPATH;
        av_object.pcontext = (AVO_CONTEXT *)NULL;
        av_object.pAttribute = (void *)argv[1];
        av_object.size = (DWORD)strlen(argv[1]);

        AVAddParameter( scan_parameters.parameters,
                        scan_parameters.nparameters,
                        AVP_OBJECT,
                        (void *)&av_object,
                        sizeof(AV_OBJECT)
                        );

        /* Start the scan */
        error = AVScanObject(init_result.engine_handle, &scan_parameters, &scan_result);
        if (error != AVE_SUCCESS)
            printf("Scan failed (error: %d)\n", (int)error);
    }
        
    /* Close the engine */
    AVClose(init_result.engine_handle);

    return 0;
}

/* Callback function gets messages from the engine and acts upon them ... */

AV_LIBRET LIBFUNC API_Callback(HSCANNER hengine, AV_MESSAGE _message, AV_PARAM1 _p1, AV_PARAM2_V2 _p2)
{
    /* Default return value */
    AV_LIBRET returnvalue = 0;

    switch(_message)
    {
        /* Miscellaneous messages */

        /* Status messages */

        case AVM_OBJECTNAME:
            printf("%s ... ",(char*)_p2.pValue);
            break;

        case AVM_OBJECTSIZE:
            printf("[%lu bytes] ",(unsigned long)_p2.qwValue);
            break;

        case AVM_OBJECTREPAIRED:
            printf("repaired\n");
            break;

        case AVM_OBJECTNOTREPAIRED:
            printf("*not* repaired (error: %lu)\n",(unsigned long)(_p2.dwValue));
            break;

        case AVM_OBJECTNOTSCANNED:
            printf("*not* scanned (error: %lu)\n",(unsigned long)(_p2.dwValue));
            break;

        case AVM_OBJECTINFECTED:
            printf("is infected with %s ... ",((AV_INFECTION*)_p2.pValue)->virus_name);
            break;


        /* Query messages ... */

        case AVM_QUERYTERMINATE:
        case AVM_QUERYDENYSCAN:
        case AVM_QUERYDENYREPAIR:
        case AVM_QUERYQUITSCANNING:
            /* Let them drop through */
            break;

        case AVM_OBJECTPASS:
            /* The engine is telling us it is about to rescan
             * our file after a clean.
             */
            printf("Rescanning ");
            break;

        case AVM_OBJECTSUMMARY:
        {
            /*  The scan is complete - report the overall status */
            switch(_p2.dwValue)
            {
                case AV_SUMMARY_OBJECTOK: 
                    printf("is OK.");
                    break;
                case AV_SUMMARY_NOTSCANNEDERROR: 
                    printf("not scanned due to errors.");
                    break;
                case AV_SUMMARY_NOTSCANNEDSETTINGS: 
                    printf("not scanned due to settings.");
                    break;
                case AV_SUMMARY_INFECTED: 
                    printf("infected.");
                    break;
            }
        }
        break;

            case AVM_OBJECTSTART:
            case AVM_OBJECTCLOSED:
            case AVM_CONTAINERSTART:
            case AVM_CONTAINERCLOSED:
                break;

        /* Fall-through case */

        default:
            printf("Received message 0x%x p1:0x%x p2:0x%lx\n\r",(unsigned)_message,(unsigned)_p1,(unsigned long)(_p2.dwValue));
            break;
        
    }

    return returnvalue;
}

