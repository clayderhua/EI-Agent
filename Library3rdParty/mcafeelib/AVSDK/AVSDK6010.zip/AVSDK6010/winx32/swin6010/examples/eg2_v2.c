/*
 *
 * Copyright (C) 2005-2018 McAfee, LLC.  All rights reserved.
 * 
 * This example takes each command line argument in turn, assumes it is
 * a filename and attempts to read the file into a memory block. That
 * memory block is then scanned for viruses using deferred IO.
 *
 * 
 */

#include "avengine.h"   /* For engine definitions */
#include "avparam.h"    /* For param manipulation macros */
#include "avstr.h"      /* For engine API string handling functions */

#ifdef NETWARE
#include <process.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>     /* assert() */


#define MAX_FOR_UNSIGNED_TYPE(_t)   ( ~( (_t) 0 ) )
#define MAX_SIZE_T                  MAX_FOR_UNSIGNED_TYPE(size_t)

/* Structure for holding file details */
struct Stream
{
    size_t size;            /* Size of the stream. */
    QWORD offset;           /* The 'file pointer'. */
    BYTE *data;             /* The data to be scanned. */
    char *filename;         /* The filename where it came from. */
};

/* Functions prototypes for this example */
AV_ERROR InitialiseEngine(AV_INITRESULT *);
struct Stream *LoadFile(const char *);
void UnLoadFile(struct Stream *);

void BuildParameterList(AV_PARAMETERS *);
void DeferredIO(AV_IOREQUEST *);

/* Callback function */
AV_LIBRET LIBFUNC API_Callback(HSCANNER, AV_MESSAGE, AV_PARAM1, AV_PARAM2 );

#if defined UNIX
#define ENGINE_DIRECTORY "../lib"
#define DIRSEPCHAR '/'
#define AV_NAMES "../dat/avvnames.dat"
#define AV_SCAN "../dat/avvscan.dat"
#define AV_CLEAN "../dat/avvclean.dat"
#else
#define ENGINE_DIRECTORY "..\\bin"
#define DIRSEPCHAR '\\'
#define AV_NAMES "..\\dat\\avvnames.dat"
#define AV_SCAN "..\\dat\\avvscan.dat"
#define AV_CLEAN "..\\dat\\avvclean.dat"
#endif

/* The maximum number of parameters we will use to initialize the engine */
#define AV_MAX_INIT_PARAMS 10



/* Function to build engine initialization parameters
 * and initialize the engine. This assumes init_result
 * has been allocated and initialised.
 */
AV_ERROR InitialiseEngine(AV_INITRESULT *init_result)
{
    AV_PARAMETERS init_params;
    AV_SINGLEPARAMETER parameters[AV_MAX_INIT_PARAMS];
    AV_ERROR error;

    AV_DATSETFILES av_dat_set;

    const char *av_dat_names[3];

    av_dat_names[0] = AV_NAMES;
    av_dat_names[1] = AV_SCAN;
    av_dat_names[2] = AV_CLEAN;

    memset(&av_dat_set, 0, sizeof(AV_DATSETFILES));
    av_dat_set.structure_size = sizeof(AV_DATSETFILES);
    av_dat_set.read_type = AV_READTYPE_DIRECT;
    av_dat_set.datfile_count = 3;
    av_dat_set.datfiles.datfile_names = av_dat_names;

    /* Initialize all structures */
    memset(&init_params, 0, sizeof(AV_PARAMETERS));
    init_params.structure_size = sizeof(AV_PARAMETERS);
    
    init_params.parameters = parameters;
    
    /* Add a callback function */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );
       
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_VIRUSDATSET,
                    (void *)&av_dat_set,
                    sizeof(AV_DATSETFILES));

    /* Tell the engine the location of the engine binaries */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_ENGINELOCATION,
                    (void *)ENGINE_DIRECTORY,
                    ( strlen(ENGINE_DIRECTORY) + 1 )
                    );

    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_APIVER,
                    (void *)AV_APIVER,
                    sizeof(void *)
                    );

    /* Then initialize */
    error = AVInitialise(&init_params,init_result);
    
    return error;
}

/* Function to load file data into a memory
 * block so we can scan it as if it is a stream
 * of memory data. This function allocates all
 * that it needs and should be freed by calling
 * UnLoadFile.
 */
struct Stream *LoadFile(const char *fname)
{
    struct Stream *stream;
    size_t size = 0;
    FILE *fp;
    size_t fnameBufferSize;
    
    fp = fopen(fname, "rb");
    if (fp == NULL)
        return NULL;
    
    if ( fseek(fp, 0, SEEK_END) != -1 )
    {
        /* get the file size into the type we use in Stream */
        size = (size_t) ftell(fp);
    }
    
    stream = (struct Stream *)malloc(sizeof(struct Stream));
    if (stream == NULL)
    {
        fclose(fp);
        return NULL;
    }
    
    stream->data = (BYTE *)malloc(size);
    if (stream->data == NULL)
    {
        free(stream);
        fclose(fp);
        return NULL;
    }
    
    fseek(fp, 0, SEEK_SET);
    /* we'll consider the file size to be whatever fread was happy to read for
     * us at this point */
    stream->size = fread(stream->data, 1, size, fp);
    stream->offset = 0;
    
    fclose(fp);
    
    fnameBufferSize = strlen(fname)+1;
    stream->filename = (char *)malloc(fnameBufferSize);
    if (stream->filename == NULL)
    {
        UnLoadFile(stream);
        return NULL;
    }

    AVSafeCopy(stream->filename, fnameBufferSize, fname);

    return stream;
}


/* Function to free any memory allocated in stream
 * including stream itself.
 */
void UnLoadFile(struct Stream *stream)
{
    if (stream != NULL)
    {
        if (stream->data != NULL)
        {
            free(stream->data);
            stream->data = NULL;
        }
        
        if (stream->filename != NULL)
        {
            free(stream->filename);
            stream->filename = NULL;
        }

        free(stream);
    }
}

/* Function to add any parameters that the scan needs.
 * It does not add a target to scan.
 */
void BuildParameterList(AV_PARAMETERS *parameters)
{
    /* The callback function */
    AVAddParameter( parameters->parameters,
                    parameters->nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );

    /* Scan for everything */
    AVAddBoolParameter( parameters->parameters,
                        parameters->nparameters,
                        AVP_SCANALLFILES);
}

/* The maximum number of parameters we will use during scanning */
#define AV_MAX_SCAN_PARAMS    20

int main(int argc ,char *argv[])
{
    /* Structure to contain initialization results */
    AV_INITRESULT init_result;
    
    /* Structures used for scanning */
    AV_PARAMETERS scan_parameters;
    AV_SINGLEPARAMETER parameters[AV_MAX_SCAN_PARAMS];
    
    AV_ERROR error;
    struct Stream *stream;
    int i;
    AV_OBJECT object;
    
    printf("Demo application for anti-virus engine\n");
    printf("Read a file into memory and scan memory block\n");
    
    
    #if defined NETWARE
    /* If on netware, register the engine with the OS */
    if (AVNLMRegister() != 0)
    {
        printf("Failed to register the engine.\n");
        return 1;
    }
    #endif
    
    /* Initialise initialisation structures. */
    memset(&init_result, 0, sizeof(AV_INITRESULT));
    init_result.structure_size = sizeof(AV_INITRESULT);
    
    /* Initialise the engine */
    error = InitialiseEngine(&init_result);
    if (error != AVE_SUCCESS)
    {
        printf("Engine failed to initialize (error: %d)\n", (int)error);
        return 1;
    }
    
    /* Initialize scanning structures */
    memset(&scan_parameters, 0, sizeof(AV_PARAMETERS));
    scan_parameters.structure_size = sizeof(AV_PARAMETERS);
    scan_parameters.parameters = parameters;
    
    /* Add any parameters needed for scanning. */
    BuildParameterList(&scan_parameters);

    memset(&object, 0, sizeof(AV_OBJECT));
    object.structure_size = sizeof(AV_OBJECT);
    object.pcontext = NULL;

    /* This parameter holds information about scanned object */
    /* It needs to be added to the parameters list only once */
    AVAddParameter( scan_parameters.parameters,
                    scan_parameters.nparameters,
                    AVP_OBJECT,
                    (void*)&object,
                    sizeof(AV_OBJECT)
                    );

    for(i = 1; i < argc; i++)
    {
        /*  Before we start scanning, let's read the file
         *  so we can scan it in memory
         */
        stream = LoadFile(argv[i]);

        if (stream != NULL)
        {
            /* Add a target to scan. In this case we tell
             * the engine to ask us for all IO.
             */
            object.type = AVOT_FILE;
            object.subtype = AVOS_USERFILETABLE;
            object.pAttribute = (void *)stream;
            object.size = sizeof(void *);

            /* Start the scan */
            error = AVScanObject(init_result.engine_handle, &scan_parameters, NULL);
            if (error != AVE_SUCCESS)
            {
                printf("Scan failed (error: %d)\n", (int)error);
            }
        
            /* Free memory used by this file */
            UnLoadFile(stream);
        }
    }
        
    /* Close the engine */
    AVClose(init_result.engine_handle);

    return 0;
}


/* Function to do all the IO for the engine. */
void DeferredIO(AV_IOREQUEST *request)
{
    /* The argument passed with AVP_USERFILETABLE is
     * passed back to the callback.
     */
    struct Stream *stream = (struct Stream *)request->io_handle;
    if (stream == NULL)
    {
        request->io_datapacket.value = 0;
        return;
    }

    /* Let's find out what IO we have been asked to do */
    switch(request->io_request)
    {
        /* The name of the file we are scanning.
         * While the filename isn't strictly needed in this example,
         * it is generally a good idea to provide it if possible
         * because if AVP_SCANALLFILES isn't provided, it is the
         * filename/extension which determines which viruses the
         * engine scans for.
         */
        case AVIORQ_PATHNAME:
            AVCopyFilename(request, stream->filename);
            break;

        case AVIORQ_ALTERNATENAME:
        case AVIORQ_FILENAME:
        {
            const char *fname = strrchr(stream->filename, DIRSEPCHAR);
            if (fname == NULL)
                fname = stream->filename;
            else
                fname++;

            AVCopyFilename(request, fname);
            break;
        }
        
        case AVIORQ_FILEEXTENSION:
        {
            /* The file extension of the current file. */
            char *fname = stream->filename + strlen(stream->filename);
            while (fname != stream->filename && (*fname != '.'))
                fname--;
            
            if (fname == stream->filename)
            {
                request->io_datapacket.filename[0] = '\0';
            }
            else
            {
                fname++;
                AVCopyExt(request, fname);
            }
            break;
        }
            
        case AVIORQ_SIZE:
            /* The size of the file we are scanning */
            request->io_datapacket.value = stream->size;
            break;

        case AVIORQ_OPENREAD:
            /* Let's fake an open */
            stream->offset = 0;
            request->io_datapacket.value = AVIOFAIL_NOFAIL;
            break;

        case AVIORQ_CLOSE:
            /* Nothing to close as we are not scanning
             * a 'real' file
             */
            break;

        case AVIORQ_READ:
        {
            /* To read, just copy the bytes from our buffer */
            
            /* Are we trying to start reading off the end of the file? */
            if(stream->offset >= stream->size)
            {
                request->io_datapacket.rw.nbytes = 0;
            }
            else
            {
                DWORD numtoread;
            
                /* Will the read go off the end of the file? */
                if ((stream->offset + request->io_datapacket.rw.nbytes) > stream->size)
                {
                    /* note: the difference then fits into a DWORD */
                    numtoread = stream->size - stream->offset;
                }
                else
                {
                    numtoread = request->io_datapacket.rw.nbytes;
                }

                /* Do the 'read' */
                memcpy(request->io_datapacket.rw.buffer, stream->data + stream->offset, numtoread);

                /* Update the file pointer */
                stream->offset += numtoread;

                /* Return the number of bytes read */
                request->io_datapacket.rw.nbytes = numtoread;
            }            
            break;
        }

        case AVIORQ_SEEKSTART:
            /* Set the file pointer. No sanity checking done here */
            stream->offset = request->io_datapacket.value;
            request->io_datapacket.value = 1;
            break;

        case AVIORQ_TELL:
            /* Where are we in the file? */
            request->io_datapacket.value = stream->offset;
            break;

        case AVIORQ_OPENWRITE:
            request->io_datapacket.value = AVIOFAIL_UNSPECIFIEDFAIL;
            break;

        case AVIORQ_WRITE:
            request->io_datapacket.rw.nbytes = 0;
            break;

        case AVIORQ_DELETE:
        case AVIORQ_CHANGESIZE:
        case AVIORQ_RENAME:
            /* This example doesn't deal with repairing infections. */
            request->io_datapacket.value = 0;
            break;

        case AVIORQ_CHANGEFILE:
        case AVIORQ_DELETEFILE:
        case AVIORQ_MOVEFILE:
            /* signal error for these unsupported requests */
            request->io_datapacket.crep.value = 0;
            break;

            /* These are related to "boot/partition sector" scanning.
             * This example doesn't deal with this. */
        case AVIORQ_GOTO:
        case AVIORQ_GOTOCHS:
        case AVIORQ_SECTORSIZE:
        case AVIORQ_SIZECHS:
        case AVIORQ_TELLCHS:
            break;

        default:
            printf("Received unknown IO request type %d\n",(int)(request->io_request));
            break;
    }
}


/* Callback function gets messages from the engine and acts upon them ... */

AV_LIBRET LIBFUNC API_Callback(HSCANNER hengine, AV_MESSAGE _message, AV_PARAM1 _p1, AV_PARAM2 _p2)
{
    /* Default return value */
    AV_LIBRET returnvalue = 0;

    switch(_message)
    {
        /* Miscellaneous messages */

        /* Status messages */

        case AVM_OBJECTNAME:
            printf("%s ... ",(const char*)(_p2.pValue));
            break;

        case AVM_OBJECTSIZE:
            printf("[%llu bytes] ", _p2.qwValue);
            break;

        case AVM_OBJECTNOTSCANNED:
            printf("*not* scanned (error: %lu)\n",(unsigned long)(_p2.dwValue));
            break;

        case AVM_OBJECTSUMMARY:
            if (_p2.dwValue == AV_SUMMARY_OBJECTOK)
                printf("is OK\n");
            break;

        case AVM_OBJECTINFECTED:
            printf("is infected with %s\n",((AV_INFECTION*)_p2.pValue)->virus_name);
            break;

        case AVM_OBJECTCLOSED:
        case AVM_OBJECTSTART:
            break;

        /* Query messages ... */

        case AVM_QUERYTERMINATE:
        case AVM_QUERYDENYSCAN:
        case AVM_QUERYDENYREPAIR:
        case AVM_QUERYQUITSCANNING:
            /* Let them drop through */
            break;

        /* Deferred IO */
        case AVM_IOREQUEST:
            DeferredIO((AV_IOREQUEST*)_p2.pValue);
            break;


        /* Fall-through case */

        default:
            printf("Received message 0x%x p1:0x%x p2:0x%lx\n\r",(unsigned)_message,(unsigned)_p1,(unsigned long)(_p2.dwValue));
            break;
        
    }

    return returnvalue;
}

