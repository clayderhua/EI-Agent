/*
 *
 * Copyright (C) 2007-2018 McAfee, LLC.  All rights reserved.
 *
 * This example takes a gdeltaavv.ini file as a parameter and creates an updated dat set.
 *
 *  /--examples  : current directory (also the location of the micro-incremental gem files
 *  +--lib       : engine directory (unix)
 *  +--dats      : location of current avvscan.dat, avvnames.dat, avvclean.dat
 *  +--new_dats  : location of the new avvscan.dat, avvnames.dat, avvclean.dat
 *
 *
 *
 */
#include "avengine.h"   /* For engine definitions */
#include "avparam.h"    /* For param manipulation macros */

#ifdef NETWARE
#include <process.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Functions prototypes for this example */
AV_ERROR InitialiseEngine(AV_INITRESULT *);
void BuildParameterList(AV_PARAMETERS *);
enum boolean { _FALSE , _TRUE };


/* Callback function */
AV_LIBRET LIBFUNC API_Callback(HSCANNER, AV_MESSAGE, AV_PARAM1, AV_PARAM2 );


#if !defined DRIVER_DIRECTORY
#if defined UNIX
#define DRIVER_DIRECTORY "../dat"
#define _DIRSEPCHAR       '/'
#else
#define DRIVER_DIRECTORY "..\\dat"
#define _DIRSEPCHAR       '\\'
#endif
#endif /* DRIVER_DIRECTORY */

/* The maximum number of parameters we will use to initialize the engine */
#define AV_MAX_INIT_PARAMS 5


#if defined UNIX
#define ENGINE_DIRECTORY "../lib"
#else
#define ENGINE_DIRECTORY "..\\bin"
#endif


/*-------------------------------------------------------------
 *  AddDatFile : adds name to the current dat set.
 *
 *-------------------------------------------------------------*/
void AddDatFile( const char * name , AV_DATSETFILES * pSet )
{
    int i = 0;
    const char ** new_set = NULL;
    const char ** old_set = NULL;
    int old_size = 0;
    int new_size = 0;
    old_size = pSet->datfile_count;
    new_size = old_size + 1;
    new_set = (const char ** )malloc( new_size * sizeof( char * ) );
    old_set = pSet->datfiles.datfile_names;

    /* Copy the old array into the new array */
    if( new_set )
    {

        for( i = 0; i < old_size; i++ )
        {
            new_set[i] = old_set[ i];
        }
        /* create a memory copy of the new name */
        new_set[ old_size ] = strdup( name );

        pSet->datfiles.datfile_names = new_set;
        pSet->datfile_count = new_size;
    } else {
        /* Free the old data */
        pSet->datfiles.datfile_names = NULL;
        pSet->datfile_count = 0;
    }
    if( old_set )
    {
        free( old_set );
    }
}
/***************************************************************************************
 *
 *  GetIniFileString.  Read a standard ini file (a section with a number of key/value pairs
 *
 ***************************************************************************************/
enum boolean GetIniFileString( const char * file_name, const char * section, const char * key, char value[ MAXPATH] )
{
    char buffer2[ MAXPATH];
    char buffer[ MAXPATH];
    enum boolean  rightSection = _FALSE;
    char SectionCheck[ MAXPATH];
    char ValueCheck[ MAXPATH];

    char test_ch;

    FILE * f = fopen (file_name ,"rt" );
    if( f == NULL ) return 0;



    sprintf( SectionCheck, "[%s]", section );
    sprintf( ValueCheck, "%s=%%[^\n]", key );


    while( fgets( buffer2, sizeof( buffer2) , f ) != NULL )
    {
        /* Remove \r and \n from end of buffer */
        sscanf( buffer2, "%[^\r\n]", buffer );

        if( strcmp( SectionCheck, buffer )  == 0 )
        {
            rightSection = _TRUE;
        } else
            /* test for [ - means leaving current section */
            if ( sscanf( buffer, "[%c", &test_ch ) == 1 )
        {
            rightSection = _FALSE;

        } else {
            /* Are we in the correct section, and is the key the correct key */
            if( rightSection && sscanf( buffer, ValueCheck, value ) == 1 )
            {
                fclose( f );
                return _TRUE;
            }
        }
    }
    fclose( f );

    return _FALSE;
}
/*********************************************************************************
 *  BuildDeltaNames : given :-
 *
 *  name of the gdeltaavv.ini,
 *  the current dat version,
 *
 *  fill out the AV_UAPPLY with the information needed to
 *  update from the current dat version to the version specified by the gdelatavv.ini
 *********************************************************************************/
enum boolean BuildDeltaNames( char * ini_name, AV_UAPPLY * dats, int current_dat )
{
    char Buffer[ MAXPATH];
    char current_dat_str[ 20];
    int lowIncrement;
    int lastIncrement;


    AV_DATSETFILES * pUpdates = NULL;

    /* Build out string value to retrieve from ini file */
    sprintf( current_dat_str, "%d", current_dat );

    /* allocate a new AV_DATSETFILES structure. */
    pUpdates = (AV_DATSETFILES * )malloc( sizeof( AV_DATSETFILES ) );
    if( pUpdates )
    {
        pUpdates->structure_size = sizeof( AV_DATSETFILES );
        pUpdates->read_type  = AV_READTYPE_DIRECT;
        pUpdates->datfile_count = 0;
        pUpdates->datfiles.datfile_names = NULL;

    }

    if( GetIniFileString( ini_name, "Contents", "LastIncremental", Buffer ) )
    {
        lastIncrement = atoi( Buffer );
    } else {
        free( pUpdates );
        return _FALSE;
    }


    if( GetIniFileString( ini_name, "Multiple Patch Table", current_dat_str, Buffer ) )
    {
        lowIncrement = atoi( Buffer );
    } else {
        /* Unable to apply incrementals on this build */
        free( pUpdates );
        return _FALSE;
    }

    /* Is the gdeltaavv.ini correct for this version of the dats? */
    if( lowIncrement != 0 && lastIncrement != 0 )
    {
        int i;

        for( i = lowIncrement; i <= lastIncrement; i++ )
        {
            char id[ MAXPATH];
            sprintf( id, "%d", i );

            if( GetIniFileString( ini_name, "Incremental Resolver", id, Buffer ) )
            {
                printf( "adding : %s\n", Buffer );
                AddDatFile( Buffer, pUpdates );
            } else {
                fprintf( stderr, "Failed to find lookup at %d\n", i );
                exit( 1 );

            }
        }
    }

    dats->updates = pUpdates;
    return _TRUE;
}
/*******************************************************************************
 * BuildDatSet
 * Given a directory, build a AV_DATSETFILES stucture to define the V2 dats for direct IO.
 *******************************************************************************/
enum boolean BuildDatSet( const char * directory, AV_DATSETFILES ** pDat_set )
{
    AV_DATSETFILES * pDats = NULL;
    enum boolean result = _FALSE;
    char dat_name[ MAXPATH ];


    pDats = (AV_DATSETFILES * ) malloc( sizeof( AV_DATSETFILES ) );
    if( pDats )
    {
        const char ** names = NULL;
        names = (const char **) malloc( 3 * sizeof( char * ) );
        if( names != NULL )
        {
            pDats->structure_size = sizeof( AV_DATSETFILES );
            pDats->read_type = AV_READTYPE_DIRECT;
            pDats->datfile_count = 3;
            pDats->datfiles.datfile_names = names;
            sprintf( dat_name, "..%c%s%cavvscan.dat", _DIRSEPCHAR, directory, _DIRSEPCHAR );
            names[0] = strdup(dat_name );

            sprintf( dat_name, "..%c%s%cavvnames.dat", _DIRSEPCHAR, directory, _DIRSEPCHAR );
            names[1] = strdup(dat_name );

            sprintf( dat_name, "..%c%s%cavvclean.dat", _DIRSEPCHAR, directory, _DIRSEPCHAR );
            names[2] = strdup(dat_name );
            result = _TRUE;
        } else {
            free( pDats );
        }
    }


    if( result == _TRUE )
    {
        *pDat_set = pDats;

    }

    return result;
}

/*******************************************************************************
 * FreeDatSet
 * Given a dat set, free the allocated memory.
 *******************************************************************************/

void FreeDatSet( AV_DATSETFILES * pset )
{
    int i;

    for( i =0; i < pset->datfile_count; i++ )
    {
        free( (char *)pset->datfiles.datfile_names[i] );
    }

    free( pset->datfiles.datfile_names );

    free( pset );


}


/*********************************************************************
 * Usage eg_update ini_file current_version
 *
 *  eg_update gdeltaavv.ini 5099
 **********************************************************************/
int main(int argc ,char *argv[])
{
    /* Structure to contain update details */
    AV_UAPPLY     dats;
    AV_ERROR error;
    enum boolean deltas_ok = _FALSE;

    if( argc != 3 )
    {
        fprintf( stderr, "Usage : %s ini_file current_version\n", argv[0] );
        exit( 1 );
    }


    dats.structure_size = sizeof( dats );
    dats.dat_set = NULL;
    dats.updated_set = NULL;
    dats.updates = NULL;

    deltas_ok = BuildDeltaNames( argv[1], &dats, atoi( argv[2] ) );

    BuildDatSet( "dat", &dats.dat_set );
    BuildDatSet( "new_dats", &dats.updated_set );

    /* Now we have information in datset, build AV_PARAMETERS */
    if( deltas_ok == _TRUE )
    {
        AV_PARAMETERS update_params;
        AV_SINGLEPARAMETER parameters[AV_MAX_INIT_PARAMS];

        memset(&update_params, 0, sizeof(AV_PARAMETERS));
        update_params.structure_size = sizeof(AV_PARAMETERS);

        update_params.parameters = parameters;

        /* Add a callback function */
        AVAddParameter( update_params.parameters,
                        update_params.nparameters,
                        AVP_CALLBACKFN,
                        (void *)API_Callback,
                        sizeof(void *)
            );


        /* Tell the engine the location of the engine binaries */
        AVAddParameter( update_params.parameters,
                        update_params.nparameters,
                        AVP_ENGINELOCATION,
                        (void *)ENGINE_DIRECTORY,
                        ( strlen(ENGINE_DIRECTORY) + 1 )
            );

        AVAddParameter( update_params.parameters,
                    update_params.nparameters,
                    AVP_APIVER,
                    (void *)AV_APIVER,
                    sizeof(void *)
                    );

        error = AVUpdate( &dats, &update_params );

        /* Free memory allocated from above */
        FreeDatSet( dats.dat_set );
        FreeDatSet( dats.updates );
        FreeDatSet( dats.updated_set );

    }
    return error;

}


AV_LIBRET LIBFUNC API_Callback(HSCANNER hengine, AV_MESSAGE _message, AV_PARAM1 _p1, AV_PARAM2 _p2)
{
    /* Default return value */
    AV_LIBRET returnvalue = 0;

    switch(_message)
    {
        /* Miscellaneous messages */
        case AVM_DAT_VERSION:
            printf( "About to update from %ld\n", (long)(_p2.dwValue) );
            break;
        case AVM_UPDATE_OK:
            printf( "dats updated OK to %ld.\n", (long)(_p2.dwValue) );
            break;
        case AVM_QUERYUPDATEDENY:
            printf( "Query deny update\n" );
            break;
        case AVM_UPDATE_ERROR:
            printf( "Update error!\n" );
            break;
        #ifdef NETWARE
        case AVM_SLICE:
            ThreadSwitch();
            break;
        #endif

        /* Status messages */

        case AVM_OBJECTNAME:
            printf("%s ... ",(const char*)_p2.pValue);
            break;

        case AVM_OBJECTSIZE:
            printf("[%llu bytes] ", _p2.qwValue);
            break;

        case AVM_OBJECTREPAIRED:
            printf("repaired\n");
            break;

        case AVM_OBJECTNOTSCANNED:
            printf("*not* scanned (error: %lu)\n",(unsigned long)(_p2.dwValue));
            break;

        case AVM_OBJECTSUMMARY:
            if (_p2.dwValue == AV_SUMMARY_OBJECTOK)
                printf("is OK\n");
            break;

        case AVM_OBJECTINFECTED:
            printf("is infected with %s\n",((AV_INFECTION*)_p2.pValue)->virus_name);
            break;

        case AVM_OBJECTCLOSED:
        case AVM_OBJECTSTART:
            break;

        /* Query messages ... */

        case AVM_QUERYTERMINATE:
        case AVM_QUERYDENYSCAN:
        case AVM_QUERYDENYREPAIR:
        case AVM_QUERYQUITSCANNING:
            /* Let them drop through */
            break;

        /* Fall-through case */

        default:
            printf("Received message 0x%x p1:0x%x p2:0x%lx\n\r",(unsigned)_message,(unsigned)_p1,(unsigned long)(_p2.dwValue));
            break;

    }

    return returnvalue;
}
