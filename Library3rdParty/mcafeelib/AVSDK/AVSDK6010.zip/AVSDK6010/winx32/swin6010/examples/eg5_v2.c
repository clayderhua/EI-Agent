/*
 *
 * Copyright (C) 2005-2018 McAfee, LLC.  All rights reserved.
 * 
 * This example takes each command line argument and passes it to the
 * engine as a file. The file is scanned and cleaned by the engine. If the file or
 * a file contained within (in the case of an archive) cannot be cleaned the scan
 * is terminated. On completion or termination of the scan, the infected state of
 * the file is reported.
 *
 * 
 */

#include "avengine.h"   /* For engine definitions */
#include "avparam.h"    /* For param manipulation macros */
#include "avstr.h"      /* For engine API string handling functions */

#ifdef NETWARE
#include <process.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

/* Functions prototypes for this example */
AV_ERROR InitialiseEngine(AV_INITRESULT *);
void DisplayDATVersion(AV_INITRESULT *init_result);

void BuildParameterList(AV_PARAMETERS *);

/* Callback function */
AV_LIBRET LIBFUNC API_Callback(HSCANNER, AV_MESSAGE, AV_PARAM1, AV_PARAM2 );

#if defined UNIX
#define ENGINE_DIRECTORY "../lib"
#define AV_NAMES "../dat/avvnames.dat"
#define AV_SCAN "../dat/avvscan.dat"
#define AV_CLEAN "../dat/avvclean.dat"
#else
#define ENGINE_DIRECTORY "..\\bin"
#define AV_NAMES "..\\dat\\avvnames.dat"
#define AV_SCAN "..\\dat\\avvscan.dat"
#define AV_CLEAN "..\\dat\\avvclean.dat"
#endif

/* A maximum number of levels of decomposition this example will allow
 * the engine to perform. This limit is here for simplicity of the example
 * code. Careful consideration should be given before limiting decomposition
 * in a production application.
 */
#define MAXNESTINGLEVEL 20

struct ObjectInfo
{
    char *detection_name;       /* The name of the detection reported by the engine */
    BOOL object_detected;       /* Set to TRUE if this object or any object nested within it has been detected */
    BOOL object_cleaned;        /* Set to TRUE if this object or any object nested within it has had a detection cleaned */
};

struct ScanInfo
{
    BOOL abort_scan;            /* Set to TRUE if the scan should be aborted by the callback */
    DWORD nesting_level;        /* The current nesting level */
    struct ObjectInfo object_info[MAXNESTINGLEVEL]; /* Info about the scanned objects at each nesing level. A fixed size
                                                       array is OK because in this example, the nesting levels have been
                                                       limited by the AVP_NESTINGLIMIT parameter. */
};

/* The maximum number of parameters we will use to initialize the engine */
#define AV_MAX_INIT_PARAMS 10




/* Function to build engine initialization parameters
 * and initialize the engine. This assumes init_result
 * has been allocated and initialised.
 */
AV_ERROR InitialiseEngine(AV_INITRESULT *init_result)
{

    AV_PARAMETERS init_params;
    AV_SINGLEPARAMETER parameters[AV_MAX_INIT_PARAMS];
    AV_ERROR error;

    AV_DATSETFILES av_dat_set;

    const char *av_dat_names[3];

    av_dat_names[0] = AV_NAMES;
    av_dat_names[1] = AV_SCAN;
    av_dat_names[2] = AV_CLEAN;

    memset(&av_dat_set, 0, sizeof(AV_DATSETFILES));
    av_dat_set.structure_size = sizeof(AV_DATSETFILES);
    av_dat_set.read_type = AV_READTYPE_DIRECT;
    av_dat_set.datfile_count = 3;
    av_dat_set.datfiles.datfile_names = av_dat_names;

    /* Initialize all structures */
    memset(&init_params, 0, sizeof(AV_PARAMETERS));
    init_params.structure_size = sizeof(AV_PARAMETERS);
    
    init_params.parameters = parameters;
    
    /* Enable the V2 API */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_APIVER,
                    (void *)AV_APIVER,
                    sizeof(void *)
                    );

    /* Add a callback function */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );
    
    /* Tell the engine the location of the engine binaries */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_ENGINELOCATION,
                    (void *)ENGINE_DIRECTORY,
                    ( strlen(ENGINE_DIRECTORY) + 1 )
                    );

    /* The DAT set to initialise the engine with */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_VIRUSDATSET,
                    (void *)&av_dat_set,
                    sizeof(AV_DATSETFILES));

    /* Then initialize */
    error = AVInitialise(&init_params,init_result);
    
    return error;
}

void DisplayDATVersion(AV_INITRESULT *init_result)
{
    if (init_result->datset_count > 0)
    {
        const AV_DATSETSTATUS *dat_status = init_result->datset_info[0];
        printf("Engine Initialised using DAT version: %d.%d\n", (int)dat_status->major_version, (int)dat_status->minor_version);
    }
}

/* Function to add any parameters that the scan needs.
 * It does not add a target to scan.
 */
void BuildParameterList(AV_PARAMETERS *parameters)
{
    /* The callback function */
    AVAddParameter( parameters->parameters,
                    parameters->nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );

    /* Limit the maximum nesting level as the structures
     * in this example code are limited.
     */
    AVAddParameter( parameters->parameters,
                    parameters->nparameters,
                    AVP_NESTINGLIMIT,
                    (void *)MAXNESTINGLEVEL,
                    sizeof(void *)
                    );

    /* Scan for everything */
    AVAddBoolParameter( parameters->parameters,
                        parameters->nparameters,
                        AVP_SCANALLFILES
                        );

    /* Scan inside archives */
    AVAddBoolParameter( parameters->parameters,
                        parameters->nparameters,
                        AVP_DECOMPARCHIVES
                        );

    /* Scan inside packed files */
    AVAddBoolParameter( parameters->parameters,
                        parameters->nparameters,
                        AVP_DECOMPEXES
                        );

    /* Clean any infections */
    AVAddBoolParameter( parameters->parameters,
                        parameters->nparameters,
                        AVP_REPAIR
                        );
}

/* The maximum number of parameters we will use during scanning */
#define AV_MAX_SCAN_PARAMS    20

int main(int argc ,char *argv[])
{
    /* Structure to contain initialization results */
    AV_INITRESULT init_result;
    
    /* Structures used for scanning */
    AV_PARAMETERS scan_parameters;
    AV_SINGLEPARAMETER parameters[AV_MAX_SCAN_PARAMS];
    
    struct ScanInfo scan_info;
    
    AV_ERROR error;
    int i;
    AV_OBJECT object;
    char* current_param;
    
    printf("Demo application for anti-virus engine\n");
    
    
    #if defined NETWARE
    /* If on netware, register the engine with the OS */
    if (AVNLMRegister() != 0)
    {
        printf("Failed to register the engine.\n");
        return 1;
    }
    #endif
    
    /* Initialise initialisation structures. */
    memset(&init_result, 0, sizeof(AV_INITRESULT));
    init_result.structure_size = sizeof(AV_INITRESULT);
    
    /* Initialise the engine */
    error = InitialiseEngine(&init_result);
    if (error != AVE_SUCCESS)
    {
        printf("Engine failed to initialize (error: %d)\n", (int)error);
        return 1;
    }

    /* Display the DAT version */
    DisplayDATVersion(&init_result);
    
    /* Initialize scanning structures */
    memset(&scan_parameters, 0, sizeof(AV_PARAMETERS));
    scan_parameters.structure_size = sizeof(AV_PARAMETERS);
    scan_parameters.parameters = parameters;
    
    /* Add any parameters needed for scanning. */
    BuildParameterList(&scan_parameters);

    /* Add the user data. */
    AVAddParameter( scan_parameters.parameters,
                    scan_parameters.nparameters,
                    AVP_USERDEFINEDDATA,
                    &scan_info,
                    sizeof(struct ScanInfo)
                    );

    /* Setup the constant values in the AV_OBJECT structure.
     * The values that change for each file are set as we
     * scan each file.
     */
    memset(&object, 0, sizeof(AV_OBJECT));
    object.structure_size = sizeof(AV_OBJECT);
    object.pcontext = NULL;

    /* This parameter holds information about scanned object */
    /* It needs to be added to the parameters list only once */
    /*  (we will update the structure pointed to by the parameter instead) */
    AVAddParameter( scan_parameters.parameters,
                    scan_parameters.nparameters,
                    AVP_OBJECT,
                    (void*)&object,
                    sizeof(AV_OBJECT)
                    );

    for(i = 1; i < argc; i++)
    {
        /* Initialise the ScanInfo structure for each scan */
        memset(&scan_info, 0, sizeof(scan_info));
 
        current_param = argv[i];

        /* Set up the current object to scan */
        object.type = AVOT_FILE;
        object.subtype = AVOS_DOSPATH;
        object.pAttribute = (void *)current_param;
        object.size = (DWORD)strlen(current_param) + 1;

        /* Start the scan */
        error = AVScanObject(init_result.engine_handle, &scan_parameters, NULL);
        if ((error == AVE_SUCCESS) ||
            (error == AVE_USERTERMINATED))
        {
            /* OK, the scan succeeded, lets see what happened. */
            if (scan_info.abort_scan == TRUE)
            {
                /* The callback terminated the scan, which means an object
                 * was not clean when the engine had finished scanning it */
                if (scan_info.object_info[0].object_detected == TRUE)
                {
                    printf("%s contains an infection (%s)\n", current_param, scan_info.object_info[0].detection_name);
                }
            }
            else if (scan_info.object_info[0].object_cleaned == TRUE)
            {
                printf("%s has had an infection removed\n", current_param);
            }
            else
            {
                printf("%s is clean\n", current_param);
            }
        }
        else
            printf("Scan failed (error: %d)\n", (int)error);
        
        /* If present, the virus name has been allocated by the
         * callback function, so it needs to be free'd.
         */
        if (scan_info.object_info[0].detection_name != NULL)
            free(scan_info.object_info[0].detection_name);

    }
        
    /* Close the engine */
    AVClose(init_result.engine_handle);
    
    return 0;
}


/* Callback function gets messages from the engine and acts upon them ... */

AV_LIBRET LIBFUNC API_Callback(HSCANNER hengine, AV_MESSAGE message, AV_PARAM1 param1, AV_PARAM2 param2)
{
    /* Default return value */
    AV_LIBRET returnvalue = 0;

    /* The user defined data as passed with AVP_USERDEFINEDDATA */
    struct ScanInfo *si = (struct ScanInfo *)EXTRACT_USER_DATA(hengine);
    struct ObjectInfo *object_info = &si->object_info[si->nesting_level];
    
    switch(message)
    {
        /* Status messages */

        case AVM_OBJECTINFECTED:
        {
            /* The current object is infected. Make a note of the name.
             * The object_detected flag is not set here, as the detection
             * may be cleaned later.
             */
             
            AV_INFECTION *infection = (AV_INFECTION *)(param2.pValue);
            size_t name_length;

            if (object_info->detection_name != NULL)
                free(object_info->detection_name);

            /* Copy the name into our structure. */
            name_length = strlen(infection->virus_name);
            object_info->detection_name = malloc(name_length + 1);
            if (object_info->detection_name != NULL)
            {
                strcpy(object_info->detection_name, infection->virus_name);
            }
            
            /* Do not set object_detected at this point. This will
             * get set by AVM_OBJECTSUMMARY if the file does not get
             * cleaned.
             */
             
            break;
        }
        
        case AVM_OBJECTREPAIRED:
        {
            /* The current object has been repaired. We need to
             * mark it as cleaned and free the detection name.
             */
            AV_INFECTION *infection = (AV_INFECTION *)param2.pValue;
            if (infection->action_taken == AVA_DELETED)
            {
                /* If the clean was to delete the object, the actual object
                 * deleted may not be the one at the current level of nesting.
                 * This is indicated by the nesting_deleted member of the
                 * AV_INFECTION structure. Any detections between the current
                 * nesting level and the nesting level at which the object
                 * was deleted need to be cleared and marked as cleaned.
                 */
                DWORD nesting_level = si->nesting_level;
                while(nesting_level >= infection->nesting_deleted)
                {
                    if (si->object_info[nesting_level].detection_name != NULL)
                        free(si->object_info[nesting_level].detection_name);
                    
                    si->object_info[nesting_level].detection_name = NULL;
                    si->object_info[nesting_level].object_cleaned = TRUE;
                    
                    nesting_level--;
                }
            }
            else
            {
                /* For other cleaning actions, these will only happen at the
                 * current nesting level. In this case, only the detection at
                 * the current nesting level needs to be cleared and marked
                 * as cleaned.
                 */
                if (object_info->detection_name != NULL)
                    free(object_info->detection_name);

                object_info->object_cleaned = TRUE;
                object_info->detection_name = NULL;
            }
            break;
        }

        case AVM_OBJECTNAME:
            break;

        case AVM_OBJECTSTART:
        {
            /* Reset the object info to not detected */
            object_info->detection_name = NULL;
            object_info->object_detected = FALSE;
            object_info->object_cleaned = FALSE;
            break;
        }
        
        case AVM_OBJECTCLOSED:
        {
            /* Do nothing */
            break;
        }
        
        case AVM_CONTAINERSTART:
        {
            si->nesting_level++;
            
            /* The nesting level is also supplied by the engine. This
             * should be equal to the value the example is maintaining.
             */
            assert(si->nesting_level == param2.dwValue);
            break;
        }
        
        case AVM_CONTAINERCLOSED:
        {
            /* The nesting level is also supplied by the engine. This
             * should be equal to the value the example is maintaining.
             */
            assert(si->nesting_level == param2.dwValue);
            
            si->nesting_level--;
            break;
        }


        case AVM_OBJECTSUMMARY:
        {
            /* If, at the end of the scan the object is marked as
             * infected, then it has not been cleaned and the scan
             * should be flagged to stop.
             */
            struct ObjectInfo *parent_info;
            
            if (param2.dwValue == AV_SUMMARY_INFECTED)
            {
                object_info->object_detected = TRUE;
                si->abort_scan = TRUE;
            }
            
            /* If any detections are in the current object, these need
             * to be reflected in the parent object.
             */
            if (si->nesting_level > 0)
            {
                parent_info = &si->object_info[si->nesting_level - 1];
                if (object_info->object_detected == TRUE)
                {
                    /* The name of the most nested detection should be
                     * reported.
                     */

                    if (parent_info->detection_name != NULL)
                        free(parent_info->detection_name);

                    parent_info->detection_name = object_info->detection_name;
                    parent_info->object_detected = TRUE;
                    
                    /* Ensure there is only one copy of the name - the
                     * parent now owns the pointer.
                     */
                    object_info->detection_name = NULL;
                }
                else
                {
                    /* There is not a current detection in this object. The
                     * detection name should not be set.
                     */
                    assert(object_info->detection_name == NULL);
                }
                
                if (object_info->object_cleaned == TRUE)
                    parent_info->object_cleaned = TRUE;
            }
            
            break;
        }

        /* Query messages ... */

        case AVM_QUERYTERMINATE:
        case AVM_QUERYDENYSCAN:
        case AVM_QUERYDENYREPAIR:
        case AVM_QUERYQUITSCANNING:
            /* If the scan is flagged to stop, returning 1 from these
             * callback messages will stop the scan in the shortest
             * possible time.
             */
            if (si->abort_scan == TRUE)
                returnvalue = 1;
            
            break;



        /* Fall-through cases */

        case AVM_OBJECTNOTSCANNED:
        case AVM_OBJECTNOTREPAIRED:
            /* These are not strictly necessary to determine if
             * something is infected, so we can ignore them here.
             * As a note of caution, in production applications,
             * it may be worth considering AVM_OBJECTNOTSCANNED
             * as this means the engine has not scanned the object.
             * The reason for not scanning will be an AV_SCANERROR
             * in param2.dwValue.
             */
            break;
        
        case AVM_OBJECTSIZE:
            break;
        
        default:
            printf("Received message 0x%x p1:0x%x p2:0x%lx\n\r",(unsigned)message,(unsigned)param1,(unsigned long)(param2.dwValue));
            break;
        
    }

    return returnvalue;
}

