/*
 *
 * Copyright (C) 2005-2018 McAfee, LLC.  All rights reserved.
 * 
 * This example takes each command line argument in turn, assumes it is
 * a filename and attempts to read the file into a memory block. That
 * memory block is then scanned for viruses using deferred IO. Any
 * viruses found in the memory block are cleaned. In the case of companion
 * viruses, the cleaning may involve manipulating files that are not the
 * one being scanned.
 *
 * 
 */

#include "avengine.h"   /* For engine definitions */
#include "avparam.h"    /* For param manipulation macros */
#include "avstr.h"      /* For engine API string handling functions */

#ifdef NETWARE
#include <process.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>     /* assert() */

#if defined UNIX
#include <unistd.h>
#elif defined WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#define MAX_FOR_UNSIGNED_TYPE(_t)   ( ~( (_t) 0 ) )
#define MAX_SIZE_T                  MAX_FOR_UNSIGNED_TYPE(size_t)

/* Structure for holding file details */
struct Stream
{
    size_t size;            /* Size of the stream. */
    QWORD offset;           /* The 'file pointer'. */
    BYTE *data;             /* The data to be scanned. */
    size_t allocated_size;  /* The size of the memory block allocated for data */
    char *filename;         /* The filename where it came from. */
    
    BOOL modified;          /* Has the file been modified? */
    BOOL deleted;           /* Has the file been deleted? */
    
    BOOL open_read;         /* The file has been opened for reading */
    BOOL open_write;        /* The file has been opened for writing */
};

/* Function prototypes for this example */
AV_ERROR InitialiseEngine(AV_INITRESULT *);
struct Stream *LoadFile(const char *);
void LocalWriteFile(struct Stream *);
void UnLoadFile(struct Stream *);

void BuildParameterList(AV_PARAMETERS *);

int LocalDeleteFile(const char *name);
int LocalMoveFile(const char *old_name, const char *new_name);

int ExtendFile(struct Stream *stream, QWORD new_size_qword);
void DeferredIO(AV_IOREQUEST *);

/* Callback function */
AV_LIBRET LIBFUNC API_Callback(HSCANNER, AV_MESSAGE, AV_PARAM1, AV_PARAM2 );

#if defined UNIX
#define ENGINE_DIRECTORY "../lib"
#define DIRSEPCHAR '/'
#define AV_NAMES "../dat/avvnames.dat"
#define AV_SCAN "../dat/avvscan.dat"
#define AV_CLEAN "../dat/avvclean.dat"
#else
#define ENGINE_DIRECTORY "..\\bin"
#define DIRSEPCHAR '\\'
#define AV_NAMES "..\\dat\\avvnames.dat"
#define AV_SCAN "..\\dat\\avvscan.dat"
#define AV_CLEAN "..\\dat\\avvclean.dat"
#endif

/* The maximum number of parameters we will use to initialize the engine */
#define AV_MAX_INIT_PARAMS 10



/* Function to build engine initialization parameters
 * and initialize the engine. This assumes init_result
 * has been allocated and initialised.
 */
AV_ERROR InitialiseEngine(AV_INITRESULT *init_result)
{
    AV_PARAMETERS init_params;
    AV_SINGLEPARAMETER parameters[AV_MAX_INIT_PARAMS];
    AV_ERROR error;

    AV_DATSETFILES av_dat_set;

    const char *av_dat_names[3];

    av_dat_names[0] = AV_NAMES;
    av_dat_names[1] = AV_SCAN;
    av_dat_names[2] = AV_CLEAN;

    memset(&av_dat_set, 0, sizeof(AV_DATSETFILES));
    av_dat_set.structure_size = sizeof(AV_DATSETFILES);
    av_dat_set.read_type = AV_READTYPE_DIRECT;
    av_dat_set.datfile_count = 3;
    av_dat_set.datfiles.datfile_names = av_dat_names;

    /* Initialize all structures */
    memset(&init_params, 0, sizeof(AV_PARAMETERS));
    init_params.structure_size = sizeof(AV_PARAMETERS);
    
    init_params.parameters = parameters;
    
    /* Add a callback function */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );
       
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_VIRUSDATSET,
                    (void *)&av_dat_set,
                    sizeof(AV_DATSETFILES));

    /* Tell the engine the location of the engine binaries */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_ENGINELOCATION,
                    (void *)ENGINE_DIRECTORY,
                    ( strlen(ENGINE_DIRECTORY) + 1 )
                    );

    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_APIVER,
                    (void *)AV_APIVER,
                    sizeof(void *)
                    );

    /* Then initialize */
    error = AVInitialise(&init_params,init_result);
    
    return error;
}

/* Function to load file data into a memory
 * block so we can scan it as if it is a stream
 * of memory data. This function allocates all
 * that it needs and should be freed by calling
 * UnLoadFile.
 */
struct Stream *LoadFile(const char *fname)
{
    struct Stream *stream;
    size_t size = 0;
    FILE *fp;
    size_t fnameBufferSize;
    
    fp = fopen(fname, "rb");
    if (fp == NULL)
        return NULL;
    
    if ( fseek(fp, 0, SEEK_END) != -1 )
    {
        /* get the file size into the type we use in Stream */
        size = (size_t) ftell(fp);
    }
    
    stream = (struct Stream *)malloc(sizeof(struct Stream));
    if (stream == NULL)
    {
        fclose(fp);
        return NULL;
    }
    
    stream->data = (BYTE *)malloc(size);
    if (stream->data == NULL)
    {
        free(stream);
        fclose(fp);
        return NULL;
    }
    stream->allocated_size = size;
    
    fseek(fp, 0, SEEK_SET);
    /* we'll consider the file size to be whatever fread was happy to read for
     * us at this point */
    stream->size = fread(stream->data, 1, size, fp);
    stream->offset = 0;
    
    fclose(fp);
    
    fnameBufferSize = strlen(fname)+1;
    stream->filename = (char *)malloc(fnameBufferSize);
    if (stream->filename == NULL)
    {
        UnLoadFile(stream);
        return NULL;
    }

    AVSafeCopy(stream->filename, fnameBufferSize, fname);

    stream->open_read = FALSE;
    stream->open_write = FALSE;

    stream->modified = FALSE;
    stream->deleted = FALSE;

    return stream;
}

/* Function to write the file represented by the
 * stream argument back to the disk.
 */
void LocalWriteFile(struct Stream *stream)
{
    if (stream->deleted != FALSE)
    {
        if (LocalDeleteFile(stream->filename) == 0)
        {
            printf("File deleted\n");
        }
        else
        {
            printf("Delete failed\n");
        }
    }
    else
    {
        if (stream->modified != FALSE)
        {
            FILE *fp = fopen(stream->filename, "wb");
            if (fp != NULL)
            {
                if (fwrite(stream->data, stream->size, 1, fp) == 1)
                {
                    printf("Write succeeded\n");
                }
                else
                {
                    printf("Write failed\n");
                }
                
                fclose(fp);
            }
        }
    }
}


/* Function to free any memory allocated in stream
 * including stream itself.
 */
void UnLoadFile(struct Stream *stream)
{
    if (stream != NULL)
    {
        if (stream->data != NULL)
        {
            free(stream->data);
            stream->data = NULL;
        }
        
        if (stream->filename != NULL)
        {
            free(stream->filename);
            stream->filename = NULL;
        }

        free(stream);
    }
}

/* Function to add any parameters that the scan needs.
 * It does not add a target to scan.
 */
void BuildParameterList(AV_PARAMETERS *parameters)
{
    /* The callback function */
    AVAddParameter( parameters->parameters,
                    parameters->nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );

    /* Tell the engine to scan all files */
    AVAddBoolParameter( parameters->parameters,
                        parameters->nparameters,
                        AVP_SCANALLFILES
                        );

    /* Tell the engine to clean the scanned files */
    AVAddBoolParameter( parameters->parameters,
                        parameters->nparameters,
                        AVP_REPAIR
                        );
}

/* The maximum number of parameters we will use during scanning */
#define AV_MAX_SCAN_PARAMS    20

int main(int argc ,char *argv[])
{
    /* Structure to contain initialization results */
    AV_INITRESULT init_result;
    
    /* Structures used for scanning */
    AV_PARAMETERS scan_parameters;
    AV_SINGLEPARAMETER parameters[AV_MAX_SCAN_PARAMS];
    
    AV_ERROR error;
    struct Stream *stream;
    int i;
    AV_OBJECT object;
    
    printf("Demo application for anti-virus engine\n");
    printf("Read a file into memory and scan/clean memory block\n");
    
    
    #if defined NETWARE
    /* If on netware, register the engine with the OS */
    if (AVNLMRegister() != 0)
    {
        printf("Failed to register the engine.\n");
        return 1;
    }
    #endif
    
    /* Initialise initialisation structures. */
    memset(&init_result, 0, sizeof(AV_INITRESULT));
    init_result.structure_size = sizeof(AV_INITRESULT);
    
    /* Initialise the engine */
    error = InitialiseEngine(&init_result);
    if (error != AVE_SUCCESS)
    {
        printf("Engine failed to initialize (error: %d)\n", (int)error);
        return 1;
    }
    
    /* Initialize scanning structures */
    memset(&scan_parameters, 0, sizeof(AV_PARAMETERS));
    scan_parameters.structure_size = sizeof(AV_PARAMETERS);
    scan_parameters.parameters = parameters;
    
    /* Add any parameters needed for scanning. */
    BuildParameterList(&scan_parameters);

    memset(&object, 0, sizeof(AV_OBJECT));
    object.structure_size = sizeof(AV_OBJECT);
    object.pcontext = NULL;

    /* This parameter holds information about scanned object */
    /* It needs to be added to the parameters list only once */
    AVAddParameter( scan_parameters.parameters,
                    scan_parameters.nparameters,
                    AVP_OBJECT,
                    (void*)&object,
                    sizeof(AV_OBJECT)
                    );

    for(i = 1; i < argc; i++)
    {
        /*  Before we start scanning, let's read the file
         *  so we can scan it in memory
         */
        stream = LoadFile(argv[i]);
        if (stream != NULL)
        {
            /* Add a target to scan. In this case we tell
             * the engine to ask us for all IO.
             */
            object.type = AVOT_FILE;
            object.subtype = AVOS_USERFILETABLE;
            object.pAttribute = (void *)stream;
            object.size = sizeof(void *);

            /* Start the scan */
            error = AVScanObject(init_result.engine_handle, &scan_parameters, NULL);
            if (error == AVE_SUCCESS)
            {
                LocalWriteFile(stream);
            }
            else
            {
                printf("Scan failed (error: %d)\n", (int)error);
            }

            /* Free memory used by this file */
            UnLoadFile(stream);
        }
    }
        
    /* Close the engine */
    AVClose(init_result.engine_handle);

    return 0;
}


/* A function to call the platform specific 
 * function(s) to delete a named file. Returns
 * 0 on success, non zero on failure.
 */
int LocalDeleteFile(const char *name)
{
    #if defined UNIX
    return unlink(name);
    #elif defined WIN32
    if (DeleteFile(name) != 0)
        return 0;
    else
        return -1;
    #else
    return -1;
    #endif
}

/* A function to call the platform specific 
 * function(s) to move a named file to another
 * named file. Returns 0 on success, non zero
 * on failure.
 */
int LocalMoveFile(const char *old_name, const char *new_name)
{
    #if defined UNIX
    return rename(old_name, new_name);
    #elif defined WIN32
    if (CopyFile(old_name, new_name, FALSE) != 0)
    {
        if (DeleteFile(old_name) == 0)
        {
            DeleteFile(new_name);
            return -1;
        }

        return 0;
    }
    else
        return -1;
    #else
    return -1;
    #endif
}

/* A function to extend the stream. If necessary,
 * a new block is allocated. The new area of the
 * data block is initialised with 0s.
 */
int ExtendFile(struct Stream *stream, QWORD new_size_qword)
{
    /* Assume its not going to work */
    int worked = -1;
    
    if ( ( new_size_qword <= MAX_SIZE_T ) && ( new_size_qword > stream->size ) )
    {
        size_t  new_size = new_size_qword;

        /* The file length is increasing. */

        if (new_size <= stream->allocated_size)
        {
            /* There is enough space allocated in the buffer
             * to allow for the new size.
             */
            
            /* Pad out the extra space with 0 */
            memset(stream->data + stream->size, 0, new_size - stream->size);
            
            stream->size = new_size;
            stream->modified = TRUE;
            
            worked = 0;
        }
        else
        {
            /* There is not enough space allocated in the buffer
             * to allow for the new size. A new buffer needs to
             * be allocated and the data copied over.
             */
            BYTE *new_data = (BYTE *)malloc(new_size);
            if (new_data != NULL)
            {
                memcpy(new_data, stream->data, stream->size);

                /* Pad out the extra space with 0 */
                memset(new_data + stream->size, 0, new_size - stream->size);

                free(stream->data);

                stream->data = new_data;
                stream->allocated_size = stream->size = new_size;

                stream->modified = TRUE;
                
                worked = 0;
            }
        }
    }
    
    return worked;
}


/* Function to do all the IO for the engine. */
void DeferredIO(AV_IOREQUEST *request)
{
    /* The argument passed with AVP_USERFILETABLE is
     * passed back to the callback.
     */
    struct Stream *stream = (struct Stream *)request->io_handle;
    if (stream == NULL)
    {
        request->io_datapacket.value = 0;
        return;
    }

    /* Let's find out what IO we have been asked to do */
    switch(request->io_request)
    {
        /* The name of the file we are scanning.
         * While the filename isn't strictly needed in this example,
         * it is generally a good idea to provide it if possible
         * because if AVP_SCANALLFILES isn't provided, it is the
         * filename/extension which determines which viruses the
         * engine scans for.
         */
        case AVIORQ_PATHNAME:
            AVCopyFilename(request, stream->filename);
            break;

        case AVIORQ_ALTERNATENAME:
        case AVIORQ_FILENAME:
        {
            const char *fname = strrchr(stream->filename, DIRSEPCHAR);
            if (fname == NULL)
                fname = stream->filename;
            else
                fname++;

            AVCopyFilename(request, fname);
            break;
        }

        case AVIORQ_FILEEXTENSION:
        {
            /* The file extension of the current file. */
            char *fname = stream->filename + strlen(stream->filename);
            while (fname != stream->filename && (*fname != '.'))
                fname--;

            if (fname == stream->filename)
            {
                request->io_datapacket.filename[0] = '\0';
            }
            else
                AVCopyExt(request, fname + 1);

            break;
        }
            
        case AVIORQ_SIZE:
            /* The size of the file we are scanning */
            request->io_datapacket.value = stream->size;
            break;

        case AVIORQ_OPENCREATE:
        case AVIORQ_OPENWRITE:
        {
            /* Open the file for writing */
            if (stream->deleted == FALSE)
            {
                /* Mark the stream as open for writing */
                stream->open_write = TRUE;
            }
            
            /* Fall through to AVIORQ_OPENREAD as opening for
             * writing also opens for reading.
             */
        }
        
        case AVIORQ_OPENREAD:
            /* Open the file for reading */
            if (stream->deleted == FALSE)
            {
                /* Reset the stream so access is from the beginning */
                stream->offset = 0;
                
                /* Mark the stream as open for reading */
                stream->open_read = TRUE;
                
                request->io_datapacket.value = AVIOFAIL_NOFAIL;
            }
            else
            {
                /* We can't open a deleted file now can we? */
                request->io_datapacket.value = AVIOFAIL_UNSPECIFIEDFAIL;
            }
            
            break;

        case AVIORQ_CLOSE:
            /* Mark the stream as closed. */
            stream->open_read = FALSE;
            stream->open_write = FALSE;
            break;

        case AVIORQ_READ:
        {
            /* To read, just copy the bytes from our buffer */
            
            if ((stream->offset >= stream->size) || (stream->open_read == FALSE))
            {
                /* We can't read from a file that is not open for
                 * reading or start reading past the end of the
                 * stream.
                 */
                request->io_datapacket.rw.nbytes = 0;
            }
            else
            {
                DWORD numtoread;
            
                /* Will the read go off the end of the file? */
                if ((stream->offset + request->io_datapacket.rw.nbytes) > stream->size)
                {
                    /* note: the difference then fits into a DWORD */
                    numtoread = stream->size - stream->offset;
                }
                else
                {
                    numtoread = request->io_datapacket.rw.nbytes;
                }

                /* Do the 'read' */
                memcpy(request->io_datapacket.rw.buffer, stream->data + stream->offset, numtoread);

                /* Update the file pointer */
                stream->offset += numtoread;

                /* Return the number of bytes read */
                request->io_datapacket.rw.nbytes = numtoread;
            }            
            break;
        }

        case AVIORQ_SEEKSTART:
            /* Set the file pointer. No sanity checking done here */
            stream->offset = request->io_datapacket.value;
            request->io_datapacket.value = 1;
            break;

        case AVIORQ_TELL:
            /* Where are we in the file? */
            request->io_datapacket.value = stream->offset;
            break;

        case AVIORQ_RENAME:
        {
            /* This could be done in the same way as AVIORQ_DELETE by marking
             * the stream as renamed and performing the actual rename at the
             * end of the scan. As cleaning of companion viruses has been
             * implemented, it keeps the code a lot more simple if the rename
             * is performed on demand here.
             */
             
            /* Start by assuming we will fail */
            DWORD return_value = 0;
            
            /* Have we been deleted? */
            if (stream->deleted == FALSE)
            {
                size_t fnameBufferSize;
                char *new_name;

                fnameBufferSize = strlen(request->io_datapacket.filename) + 1;
                new_name = (char *)malloc(fnameBufferSize);
                if (new_name != NULL)
                {
                    AVSafeCopy(new_name, fnameBufferSize, request->io_datapacket.filename);
                    if (LocalMoveFile(stream->filename, new_name) == 0)
                    {
                        free(stream->filename);
                        stream->filename = new_name;
                        
                        return_value = 1;
                    }
                    else
                        free(new_name);
                }
            }
            
            request->io_datapacket.value = return_value;
            break;
        }
        
        case AVIORQ_DELETE:
        {
            /* Mark the stream as deleted. The actual delete will
             * happen after the scan.
             */
            stream->deleted = TRUE;
            
            /* Make sure the file is marked as closed */
            stream->open_read = FALSE;
            stream->open_write = FALSE;
            
            request->io_datapacket.value = 1;
            break;
        }
        
        case AVIORQ_CHANGESIZE:
        {
            /* Change the size of the file to the new size. The new
             * size could be larger or smaller than the current size.
             */
            if (stream->open_write != FALSE)
            {
                QWORD new_size = request->io_datapacket.value;

                if (new_size > stream->size)
                {
                    /* The file size is going to increase, so we need
                     * to extend the file
                     * (note: ExtendFile() updates stream->modified)
                     */
                    if (ExtendFile(stream, new_size) != 0)
                        request->io_datapacket.value = 0;
                    else
                        request->io_datapacket.value = 1;
                }
                else if (new_size < stream->size)
                {
                    /* The new size is smaller, so just shrink it. The
                     * stream->allocated_size remains unchanged in case
                     * the size grows later on.
                     */
                    stream->size = new_size;
                    
                    stream->modified = TRUE;
                    
                    request->io_datapacket.value = 1;
                }
                else
                {
                    /* same size as before, no changes needed */
                    request->io_datapacket.value = 1;
                }
            }
            else
            {
                /* We can't change the size of a stream if it isn't open
                 * for writing.
                 */
                request->io_datapacket.value = 0;
            }
            
            break;
        }
        
        case AVIORQ_WRITE:
        {
            /* To write, just copy the bytes to our buffer */
            
            if(stream->open_write == FALSE)
            {
                /* We can't write to a stream that isn't open for writing. */
                request->io_datapacket.rw.nbytes = 0;
            }
            else
            {
                DWORD numtowrite;
                
                /* Will the write go off the end of the file? If so, attempt to increase the
                 * file size to allow for this. If that fails, reduce the number of bytes
                 * written.
                 */
                if ((stream->offset + request->io_datapacket.rw.nbytes) > stream->size)
                {
                    if (ExtendFile(stream, (stream->offset + request->io_datapacket.rw.nbytes)) != 0)
                    {
                        /* The attempt to extend the file failed, so lets write what we can. */
                        if (stream->offset >= stream->size)
                        {
                            /* The write starts off the end of the file, so
                             * we can't write anything.
                             */
                            request->io_datapacket.rw.nbytes = 0;
                        }
                        else if ((stream->offset + request->io_datapacket.rw.nbytes) > stream->size)
                        {
                            /* The write goes off the end of the file, so we
                             * need to reduce the number of bytes to write.
                             * Note: the difference (size - offset) fits into
                             * a DWORD (the "if" condition ensures that).
                             */
                            request->io_datapacket.rw.nbytes = (DWORD)( stream->size - stream->offset );
                        }
                    }
                }

                numtowrite = request->io_datapacket.rw.nbytes;

                if (numtowrite > 0)
                {
                    /* Do the 'write' */
                    memcpy(stream->data + stream->offset, request->io_datapacket.rw.buffer, numtowrite);

                    /* Mark the stream as modified */
                    stream->modified = TRUE;

                    /* Update the file pointer */
                    stream->offset += numtowrite;

                    /* the file is now at least as big as to fit everything
                     * we've just written */
                    assert( stream->offset <= stream->size );

                    /* Return the number of bytes written */
                    request->io_datapacket.rw.nbytes = numtowrite;
                }
            }
            break;
        }
        
        case AVIORQ_CHANGEFILE:
        {
            /* We need to copy a file over ourselves and
             * then use that file as the one to scan.
             */
             
            request->io_datapacket.crep.value = 0;
            
            /* Delete the current file being worked on */
            if (LocalDeleteFile(stream->filename) == 0)
            {
                /* Move a new file over what we have just deleted */
                if (LocalMoveFile(request->io_datapacket.crep.name1, stream->filename) == 0)
                {
                    /* Reinitialise our stream with the new file. Do
                     * this by loading a new stream structure, swaping
                     * new data with the old stream structure and then
                     * deleting the new structure.
                     */
                    struct Stream *new_stream = LoadFile(stream->filename);
                    if ( new_stream != NULL )
                    {
                        BYTE *tmp_data;

                        stream->size = new_stream->size;
                        stream->offset = 0;

                        tmp_data = stream->data;
                        stream->data = new_stream->data;
                        new_stream->data = tmp_data;

                        stream->allocated_size = new_stream->allocated_size;
                        stream->modified = FALSE;
                        stream->deleted = FALSE;

                        /* The stream should be initialised to closed */
                        stream->open_read = FALSE;
                        stream->open_write = FALSE;

                        UnLoadFile(new_stream);

                        request->io_datapacket.crep.value = 1;
                    }
                }
            }
            break;
        }
        
        case AVIORQ_MOVEFILE:
        {
            /* We need to move some files about */
            if (LocalMoveFile(request->io_datapacket.crep.name1, request->io_datapacket.crep.name2) == 0)
                request->io_datapacket.crep.value = 1;
            else
                request->io_datapacket.crep.value = 0;
            
            break;
        }
        
        case AVIORQ_DELETEFILE:
        {
            /* We need to delete a file that is not our self */
            if (LocalDeleteFile(request->io_datapacket.crep.name1) == 0)
                request->io_datapacket.crep.value = 1;
            else
                request->io_datapacket.crep.value = 0;
            
            break;
        }
        
            /* These are related to "boot/partition sector" scanning.
             * This example doesn't deal with this. */
        case AVIORQ_GOTO:
        case AVIORQ_GOTOCHS:
        case AVIORQ_SECTORSIZE:
        case AVIORQ_SIZECHS:
        case AVIORQ_TELLCHS:
            break;

        default:
            printf("Received unknown IO request type %d\n",(int)(request->io_request));
            break;
    }
}


/* Callback function gets messages from the engine and acts upon them ... */

AV_LIBRET LIBFUNC API_Callback(HSCANNER hengine, AV_MESSAGE _message, AV_PARAM1 _p1, AV_PARAM2 _p2)
{
    /* Default return value */
    AV_LIBRET returnvalue = 0;

    switch(_message)
    {
        /* Miscellaneous messages */

        /* Status messages */

        case AVM_OBJECTNAME:
            printf("%s ... ",(const char*)(_p2.pValue));
            break;

        case AVM_OBJECTSIZE:
            printf("[%llu bytes] ", _p2.qwValue);
            break;

        case AVM_OBJECTREPAIRED:
            /* Note: _p2.pValue holds an "AV_INFECTION *" that describes the
             * repair action. */
            printf("repaired\n");
            break;

       case AVM_OBJECTNOTREPAIRED:
            printf("*not* repaired (error: %lu)\n",(unsigned long)(_p2.dwValue));
            break;

        case AVM_OBJECTNOTSCANNED:
            printf("*not* scanned (error: %lu)\n",(unsigned long)(_p2.dwValue));
            break;

        case AVM_OBJECTSUMMARY:
            if (_p2.dwValue == AV_SUMMARY_OBJECTOK)
                printf("is OK\n");
            break;

        case AVM_OBJECTINFECTED:
            printf("is infected with %s\n",((AV_INFECTION*)_p2.pValue)->virus_name);
            break;

        case AVM_OBJECTSTART:
        case AVM_OBJECTCLOSED:
        case AVM_CONTAINERSTART:
        case AVM_CONTAINERCLOSED:
            break;

        /* Query messages ... */

        case AVM_QUERYTERMINATE:
        case AVM_QUERYDENYSCAN:
        case AVM_QUERYDENYREPAIR:
        case AVM_QUERYQUITSCANNING:
            /* Let them drop through */
            break;

        /* Deferred IO */
        case AVM_IOREQUEST:
            DeferredIO((AV_IOREQUEST*)_p2.pValue);
            break;

        case AVM_OBJECTPASS:
            /* The engine is telling us it is about to rescan
             * our file after a clean.
             */
            printf("Rescanning ");
            break;

        /* Fall-through case */

        default:
            printf("Received message 0x%x p1:0x%x p2:0x%lx\n\r",(unsigned)_message,(unsigned)_p1,(unsigned long)(_p2.dwValue));
            break;
        
    }

    return returnvalue;
}

