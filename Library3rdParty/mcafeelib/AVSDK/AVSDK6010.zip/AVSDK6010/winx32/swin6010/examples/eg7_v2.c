/*
 *
 * Copyright (C) 2005-2018 McAfee, LLC.  All rights reserved.
 * 
 * This example gets the Registry Target Table from the engine
 * and scans the registry as directed by the table.
 *
 * 
 */

#ifndef WIN32
#error "This example only works with WIN32."
#endif

#include "avengine.h"   /* For engine definitions */
#include "avparam.h"    /* For param manipulation macros */
#include "avstr.h"      /* For engine API string handling functions */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

/* Functions prototypes for this example */
AV_ERROR InitialiseEngine(AV_INITRESULT *, IO_HANDLE *);

void BuildParameterList(AV_PARAMETERS *, BOOL);

AV_ERROR GetRegistryTargetTable(HENGINE);
BOOL BuildRegTargetTable(AV_REGTARGETTABLE *);
void FreeRegTargets();

void ScanRegistryTargets(HENGINE , AV_PARAMETERS *, AV_OBJECT*);
void RegistryScanKeys(HENGINE , const char *, UINT32 , AV_PARAMETERS *, AV_OBJECT*);
void RegistryScanValues(HENGINE , const char* , UINT32 , AV_PARAMETERS *, AV_OBJECT*);
BOOL OpenBaseKey(const char *, HKEY *);
void CreateRegistryPath(char* regPath, const char *, const char *, const char *);
AV_ERROR RegistryScan(HENGINE, const char *, UINT32, AV_PARAMETERS *, AV_OBJECT*);

/* Callback function */
AV_LIBRET LIBFUNC API_Callback(HSCANNER, AV_MESSAGE, AV_PARAM1, AV_PARAM2_V2 );

#define ENGINE_DIRECTORY "..\\bin"
#define AV_NAMES "..\\dat\\avvnames.dat"
#define AV_SCAN "..\\dat\\avvscan.dat"
#define AV_CLEAN "..\\dat\\avvclean.dat"

/* The maximum number of parameters we will use to initialize the engine */
#define AV_MAX_INIT_PARAMS 10

/* Initialise Registry Root Key Names */
const char* szHKLM = "HKLM"; 
const char* szHKCU = "HKCU"; 
const char* szHKU  = "HKU"; 
const char* szHKCR = "HKCR"; 

AV_REGTARGETTABLE g_regTargetTable;

/* Function to build engine initialization parameters
 * and initialize the engine. This assumes init_result
 * has been allocated and initialised.
 */
AV_ERROR InitialiseEngine(AV_INITRESULT *init_result, IO_HANDLE* av_handles)
{

    AV_PARAMETERS init_params;
    AV_SINGLEPARAMETER parameters[AV_MAX_INIT_PARAMS];
    AV_ERROR error;

    AV_DATSETFILES av_dat_set;

    const char *av_dat_names[3];

    av_dat_names[0] = AV_NAMES;
    av_dat_names[1] = AV_SCAN;
    av_dat_names[2] = AV_CLEAN;

    memset(&av_dat_set, 0, sizeof(AV_DATSETFILES));
    av_dat_set.structure_size = sizeof(AV_DATSETFILES);
    av_dat_set.read_type = AV_READTYPE_DIRECT;
    av_dat_set.datfile_count = 3;
    av_dat_set.datfiles.datfile_names = av_dat_names;

    /* Initialize all structures */
    memset(&init_params, 0, sizeof(AV_PARAMETERS));
    init_params.structure_size = sizeof(AV_PARAMETERS);
    
    init_params.parameters = parameters;
    
    /* Add a callback function */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );
       
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_VIRUSDATSET,
                    (void *)&av_dat_set,
                    sizeof(AV_DATSETFILES));

    /* Tell the engine the location of the engine binaries */
    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_ENGINELOCATION,
                    (void *)ENGINE_DIRECTORY,
                    ( strlen(ENGINE_DIRECTORY) + 1 )
                    );

    AVAddParameter( init_params.parameters,
                    init_params.nparameters,
                    AVP_APIVER,
                    (void *)AV_APIVER,
                    sizeof(void *)
                    );

    /* Then initialize */
    error = AVInitialise(&init_params,init_result);
    
    return error;
}

/* Function to add any parameters that the scan needs.
 * It does not add a target to scan.
 */
void BuildParameterList(AV_PARAMETERS *parameters, BOOL clean)
{
    /* The callback function */
    AVAddParameter( parameters->parameters,
                    parameters->nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );

    if (clean != FALSE)
    {
        /* Tell the engine to clean the scanned files */
        AVAddBoolParameter( parameters->parameters,
                            parameters->nparameters,
                            AVP_REPAIR
                            );
    }
}

/* Build a registry path as "basekey\\key|value"
 * and escape any '|' character.
 */
void CreateRegistryPath(char* regPath, const char* base_key, const char* key, const char* value)
{
    size_t len = strlen(base_key);
    size_t inPos = 0;
    size_t outPos = 0;

    for (inPos = 0; inPos<len; inPos++)
    {
        char current = base_key[inPos];
        if (current == '|')
        {
            regPath[outPos++] = '\\';
        }
        regPath[outPos++] = current;
    }

    if (key != NULL)
    {
        regPath[outPos++] = '\\';

        len = strlen(key);
        for (inPos = 0; inPos<len; inPos++)
        {
            char current = key[inPos];
            if (current == '|')
            {
                regPath[outPos++] = '\\';
            }
            regPath[outPos++] = current;
        }
    }

    if (value != NULL)
    {
        regPath[outPos++] = '|';

        len = strlen(value);
        for (inPos = 0; inPos<len; inPos++)
        {
            char current = value[inPos];
            if (current == '|')
            {
                regPath[outPos++] = '\\';
            }
            regPath[outPos++] = current;
        }
    }

    regPath[outPos++] = '\0';
}

/* Open the base registry key to walk through */
BOOL OpenBaseKey(const char* path, HKEY* phKey)
{
    HKEY hRootKey = 0;
    const char* baseKey = path;

    /* Get the root key. e.g. "HKLM\" */
    if (_strnicmp(path, szHKLM, strlen(szHKLM)) == 0)
    {
        hRootKey = HKEY_LOCAL_MACHINE;
        baseKey += strlen(szHKLM);
    }
    else if (_strnicmp(path, szHKCU, strlen(szHKCU)) == 0)
    {
        hRootKey = HKEY_CURRENT_USER;
        baseKey += strlen(szHKLM);
    }
    else if (_strnicmp(path, szHKU, strlen(szHKU)) == 0)
    {
        hRootKey = HKEY_USERS;
        baseKey += strlen(szHKLM);
    }
    else if (_strnicmp(path, szHKCR, strlen(szHKCR)) == 0)
    {
        hRootKey = HKEY_CLASSES_ROOT;
        baseKey += strlen(szHKLM);
    }

    if (hRootKey == 0)
    {
        return FALSE;    /* invalid symbol for root key */
    }

    /* Back slash or NUL allowed after the root key. */
    if (*baseKey == '\\')
    {
        ++baseKey;
    }
    else if (*baseKey != '\0')
    {
        return FALSE;    /* invalid symbol for root key */
    }

    /* Open the sub key of the root key. */
    if (RegOpenKeyEx(hRootKey, baseKey, 0, KEY_ALL_ACCESS, phKey) != ERROR_SUCCESS)
    {
        return FALSE;    /* invalid symbol for root key */
    }
    return TRUE;
}

/*
 * Scan all the Registry keys in path with the given
 * context and parameters.
 */
void RegistryScanKeys(HENGINE hengine, const char* path, UINT32 context, AV_PARAMETERS *pParameters, AV_OBJECT* av_object)
{
    char fullPath[1024];
    char keyName[1024];
    HKEY hKey;
    DWORD index;
    DWORD keyNameLen;

    /* Open the key we're going to walk thru. */
    if (OpenBaseKey(path, &hKey))
    {
        /* Setup enum for first key. */
        index = 0;
        keyNameLen = sizeof(keyName);

        if (RegEnumKeyEx(hKey, index, keyName, &keyNameLen, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
        {
            do
            {
                /* Create a registry path for the key (with no value). */
                CreateRegistryPath(fullPath, path, keyName, NULL);

                /* Scan this path. */
                RegistryScan(hengine, fullPath, context, pParameters, av_object);

                /* Setup enum for next key. */
                ++index;
                keyNameLen = sizeof(keyName);
            }
            while (RegEnumKeyEx(hKey, index, keyName, &keyNameLen, NULL, NULL, NULL, NULL) == ERROR_SUCCESS);
        }

        /* Close the base key. */
        RegCloseKey(hKey);
    }
}

/*
 * Scan all the Registry values in path with the given
 * context and parameters.
 */
void RegistryScanValues(HENGINE hengine, const char* path, UINT32 context, AV_PARAMETERS *pParameters, AV_OBJECT* av_object)
{
    char fullPath[1024];
    HKEY hKey;
    DWORD index;
    char valueName[1024];
    DWORD valueNameLen;

    /* Open the key we're going to walk thru. */
    if (OpenBaseKey(path, &hKey))
    {
        /* Setup enum for first value. */
        index = 0;
        valueNameLen = sizeof(valueName);
    
        if (RegEnumValue(hKey, index, valueName, &valueNameLen, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
        {
            do
            {
                /* Create a registry path for the value. */
                CreateRegistryPath(fullPath, path, NULL, valueName);

                /* Scan this path. */
                RegistryScan(hengine, fullPath, context, pParameters, av_object);

                /* Setup enum for next value. */
                ++index;
                valueNameLen = sizeof(valueName);
            }
            while (RegEnumValue(hKey, index, valueName, &valueNameLen, NULL, NULL, NULL, NULL) == ERROR_SUCCESS);
        }

        /* Close the base key. */
        RegCloseKey(hKey);
    }
}


/* Scan the registry according to the Registry Target Table. */
void ScanRegistryTargets(HENGINE hengine, AV_PARAMETERS *pParameters, AV_OBJECT* av_object)
{
    DWORD n;

    /* Process each target in the table. */
    for (n=0; n<g_regTargetTable.nTargets; n++)
    {
        AV_REGTARGET* target = g_regTargetTable.regTargets[n];
        if (target->type == AVR_KEY)
        {
            RegistryScanKeys(hengine, target->path, target->context, pParameters, av_object);
        }
        else
        {
            RegistryScanValues(hengine, target->path, target->context, pParameters, av_object);
        }
    }
}

/* Use AVRetrieveInstanceInfo to get the Registry Target Table. */
AV_ERROR GetRegistryTargetTable(HENGINE hengine)
{
    AV_PARAMETERS info_parameters;
    AV_SINGLEPARAMETER parameters[5];

    /* Initialize scanning structures */
    memset(&info_parameters, 0, sizeof(AV_PARAMETERS));
    info_parameters.structure_size = sizeof(AV_PARAMETERS);
    info_parameters.parameters = parameters;

    /* Add a callback function */
    AVAddParameter( info_parameters.parameters,
                    info_parameters.nparameters,
                    AVP_CALLBACKFN,
                    (void *)API_Callback,
                    sizeof(void *)
                    );

    /* We want the Registry Target Table info. */
    AVAddBoolParameter( info_parameters.parameters,
                    info_parameters.nparameters,
                    AVP_REGTARGETS);

    /* Get the info.
    (Info is passed back using the AVM_INSTANCEINFO callback.)
    */
    return AVRetrieveInstanceInfo(hengine, &info_parameters);
}

/* Copy the Registry Target Table passed back by the engine. */
BOOL BuildRegTargetTable(AV_REGTARGETTABLE* inTable)
{
    DWORD nTargets;
    AV_REGTARGET* srcTarget;
    AV_REGTARGET* dstTarget;
    DWORD n;
    BOOL ok = TRUE;

    /* Setup the structure. */
    memset(&g_regTargetTable, 0, sizeof(g_regTargetTable));
    g_regTargetTable.structure_size = sizeof(g_regTargetTable);

    /* Allocate the array of target pointers. */
    nTargets = inTable->nTargets;
    g_regTargetTable.nTargets = nTargets;
    g_regTargetTable.regTargets = (AV_REGTARGET**) malloc(sizeof(AV_REGTARGET*) * nTargets);
    if (g_regTargetTable.regTargets != NULL)
    {
        for (n=0; n<nTargets; n++)
        {
            srcTarget = inTable->regTargets[n];

            /* Allocate this target. */
            dstTarget = (AV_REGTARGET*) malloc(sizeof(AV_REGTARGET));
            if (dstTarget == NULL)
            {
                ok = FALSE;
                break;
            }

            /* Copy this target. */
            dstTarget->structure_size = srcTarget->structure_size;
            dstTarget->context = srcTarget->context;
            dstTarget->type = srcTarget->type;
            if (srcTarget->path != NULL)
            {
                size_t destSize = strlen(srcTarget->path) + 1;

                dstTarget->path = (char*)malloc(destSize);
                if (dstTarget->path == NULL)
                {
                    ok = FALSE;
                    break;
                }

                AVSafeCopy(dstTarget->path, destSize, srcTarget->path);
            }
            else
            {
                dstTarget->path = NULL;
            }

            /* Add to the table. */
            g_regTargetTable.regTargets[n] = dstTarget;
        }
    }
    else
    {
        ok = FALSE;
    }
    return ok;
}


/* Free the dynamic data in the Registry Target Table. */
void FreeRegTargets()
{
    DWORD nTargets;
    DWORD n;
    AV_REGTARGET* target;

    nTargets = g_regTargetTable.nTargets;
    if (g_regTargetTable.regTargets != NULL)
    {
        for (n=0; n<nTargets; n++)
        {
            target = g_regTargetTable.regTargets[n];
            if (target != NULL)
            {
                if (target->path != NULL)
                {
                    free((void*)target->path);
                }
                free((void*)target);
            }
        }
        free((void*)g_regTargetTable.regTargets);
    }
    memset(&g_regTargetTable, 0, sizeof(g_regTargetTable));
}



AV_ERROR RegistryScan(HENGINE hengine, const char* reg_path, UINT32 context, AV_PARAMETERS *pParameters, AV_OBJECT* av_object)
{
    AV_ERROR error;

    /* Setup registry context */
    DWORD reg_context_data[] = { (DWORD) context };
    AVO_CONTEXT reg_context = 
        {
            sizeof (reg_context_data) / sizeof (reg_context_data[0]),
            reg_context_data
        };

    /* Add a registry target to scan. */
    av_object->pAttribute = (void*)reg_path;
    av_object->size = (DWORD)strlen(reg_path);
    av_object->pcontext = &reg_context;

    /* Start the scan */
    error = AVScanObject(hengine, pParameters, NULL);
    if (error != AVE_SUCCESS)
        printf("Scan failed (error: %d)\n", (int)error);

    return error;
}

/* The maximum number of parameters we will use during scanning */
#define AV_MAX_SCAN_PARAMS    20

int main(int argc ,char *argv[])
{
    /* Structure to contain initialization results */
    AV_INITRESULT init_result;
    
    /* Structures used for scanning */
    AV_PARAMETERS scan_parameters;
    AV_SINGLEPARAMETER parameters[AV_MAX_SCAN_PARAMS];
    AV_OBJECT av_object;
    
    AV_ERROR error;
    BOOL do_clean = FALSE;

    IO_HANDLE av_handles[3];
    
    printf("Demo application for anti-virus engine\n");
    printf("Scan the registry according to the Registry Target Table.\n");
       
    /* Initialise initialisation structures. */
    memset(&init_result, 0, sizeof(AV_INITRESULT));
    init_result.structure_size = sizeof(AV_INITRESULT);
    memset(av_handles, 0, sizeof(av_handles));
    
    /* Initialise the engine */
    error = InitialiseEngine(&init_result, av_handles);
    if (error != AVE_SUCCESS)
    {
        printf("Engine failed to initialize (error: %d)\n", (int)error);
        return 1;
    }
    
    /* Request the Registry Target Table from the engine */
    error = GetRegistryTargetTable(init_result.engine_handle);
    if (error != AVE_SUCCESS)
    {
        printf("Failed to get Registry Target Table (error: %d)\n", (int)error);
        return 1;
    }

    /* Initialize scanning structures */
    memset(&scan_parameters, 0, sizeof(AV_PARAMETERS));
    scan_parameters.structure_size = sizeof(AV_PARAMETERS);
    scan_parameters.parameters = parameters;
     
    /* Add any parameters needed for scanning. */
    BuildParameterList(&scan_parameters, do_clean);

    /* Setup the common parts of the AV object. */
    memset(&av_object, 0, sizeof(AV_OBJECT));
    av_object.structure_size = sizeof(AV_OBJECT);
    av_object.type = AVOT_REGISTRY;
    av_object.subtype = AVOS_DOSPATH;

    AVAddParameter( scan_parameters.parameters,
                scan_parameters.nparameters,
                AVP_OBJECT,
                (void *)&av_object,
                sizeof(AV_OBJECT)
                );

    /* Scan registry as specified in the Registry Target Table */
    ScanRegistryTargets(init_result.engine_handle, &scan_parameters, &av_object);

    /* Free the Registry Target Table */
    FreeRegTargets();
        
    /* Close the engine */
    AVClose(init_result.engine_handle);

    return 0;
}

/* Callback function gets messages from the engine and acts upon them ... */

AV_LIBRET LIBFUNC API_Callback(HSCANNER hengine, AV_MESSAGE _message, AV_PARAM1 _p1, AV_PARAM2_V2 _p2)
{
    /* Default return value */
    AV_LIBRET returnvalue = 0;

    switch(_message)
    {
        /* Miscellaneous messages */

        /* Status messages */

        case AVM_OBJECTNAME:
            printf("%s ... ",(const char*)(_p2.pValue));
            break;

        case AVM_OBJECTSIZE:
            break;

        case AVM_OBJECTREPAIRED:
            printf("repaired\n");
            break;

        case AVM_OBJECTNOTREPAIRED:
            printf("*not* repaired (error: %lu)\n",(unsigned long)(_p2.dwValue));  
            break;

        case AVM_OBJECTNOTSCANNED:
            printf("*not* scanned (error: %lu)\n",(unsigned long)(_p2.dwValue));
            break;

        case AVM_OBJECTINFECTED:
            printf("is infected with %s ... ",((AV_INFECTION*)_p2.pValue)->virus_name);
            break;

        case AVM_OBJECTCLOSED:
            break;

        /* Query messages ... */

        case AVM_QUERYTERMINATE:
        case AVM_QUERYDENYSCAN:
        case AVM_QUERYDENYREPAIR:
        case AVM_QUERYQUITSCANNING:
            /* Let them drop through */
            break;

        case AVM_OBJECTPASS:
            /* The engine is telling us it is about to rescan
             * our file after a clean.
             */
            printf("Rescanning ");
            break;

        case AVM_OBJECTSUMMARY:
        {
            /*  The scan is complete - report the overall status */
            switch(_p2.dwValue)
            {
                case AV_SUMMARY_OBJECTOK: 
                    printf("is OK.\n");
                    break;
                case AV_SUMMARY_NOTSCANNEDERROR: 
                    printf("not scanned due to errors.\n");
                    break;
                case AV_SUMMARY_NOTSCANNEDSETTINGS: 
                    printf("not scanned due to settings.\n");
                    break;
                case AV_SUMMARY_INFECTED: 
                    printf("infected.\n");
                    break;
            }
        }
        break;

        case AVM_OBJECTSTART:
        case AVM_CONTAINERSTART:
        case AVM_CONTAINERCLOSED:
        break;

        case AVM_INSTANCEINFO:
        {
            if (_p1 == AVINFO_REGTARGETS)
            {
                if (BuildRegTargetTable((AV_REGTARGETTABLE*)_p2.pValue) == FALSE)
                {
                    FreeRegTargets();
                }
            }
            break;
        }

        /* Fall-through case */

        default:
            printf("Received message 0x%x p1:0x%x p2:0x%lx\n\r",(unsigned)_message,(unsigned)_p1,(unsigned long)(_p2.dwValue));
            break;
        
    }

    return returnvalue;
}

