               Release Notes for
           McAfee(R) Anti-Virus Engine  
          Application Programing Interface 
                Version 6.0.10  
       Copyright (C) 2019 McAfee, LLC.
              All Rights Reserved


================================================

- Engine Version:      6010 

================================================  

Thank you for using this software. This file 
contains important information regarding this 
release. We strongly recommend that you read 
the entire document.

Please ensure that you update the DAT files on your 
computer to the latest version.

    IMPORTANT:
    McAfee strongly recommends that you use any
    pre-release software (alpha, beta or release
    candidate) in a test environment only.
    Pre-release software should not be installed in
    a production environment.

    McAfee does not support automatic upgrading of a
    pre-release version of the software. To upgrade
    to a later beta release, a release candidate, or
    a production release of the software, you must
    first uninstall the existing version of the 
    software.


________________________________________________
WHAT'S IN THIS FILE

-   New Features
-   System Requirements
-   Installation and Upgrade
   -   Installing on a UNIX System 
   -   Installing on a Macintosh OS X System 
   -   Installing on a Microsoft Windows System 
   -   List of Files (UNIX) 
   -   List of Files (Macintosh OS X) 
   -   List of Files (32-bit Microsoft Windows)
   -   List of Files (64-bit Microsoft Windows)
-   Known Issues
-   Known Limitation
-   Documentation
-   Engine End-of-Life (EOL) Program
   -  The Problem
   -  The Solution
   -  The Engine End-Of-Life Program
-   Participating in the McAfee Beta Program


________________________________________________
NEW FEATURES

The Anti-Virus Engine in this package has the following new features:

- 	Support for Microsoft Windows 10 Case Sensitivitiy

-	Several Bug Fixes and Performance Improvement

________________________________________________
SYSTEM REQUIREMENTS
  
This readme.txt file is provided with all 
distributions of the software.  The system 
requirements vary according to the platform. 

-   At least 512 MB of free hard disk space

-   At least an additional 512 MB of free hard disk
    space reserved for temporary files

-   At least 512 MB of RAM for scanning operations 
    (1024 MB recommended minimum)

-   At least 1024 MB of RAM for updating operations

To learn which platforms are currently supported, 
or to request additional platform support, please
contact your sales representative or support 
account manager.


________________________________________________
INSTALLATION and UPGRADE

Follow the installation instructions that are 
relevant to your software platform. 

Read the following notes before you upgrade to 
the 6010 Anti-Malware Engine:


INSTALLING ON A UNIX SYSTEM

We distribute the engine and API files as a .tar
package that you can download from our web site 
and copy into your development area.

To install the new files directly:

1. Download the appropriate UNIX distribution 
   package for your system into a temporary 
   directory on your computer.

   The distributions, listed according to their 
   corresponding operating systems, are:

   AIX                          saix6010.tar
   FreeBSD v8/9/10 (x86_32)     sbs76010.tar
   FreeBSD v8/9/10 (x86_64)     sb746010.tar
   HP-UX                        shpx6010.tar
   Linux (x86_32)               slp46010.tar
   Linux (x86_64)               sl646010.tar
   Solaris SPARC                ssun6010.tar
   Solaris x86                  ss866010.tar


   NOTE:

   Linux (x86_32) -- This links to libstdc++.so.5
   which is only present in newer Linux 
   distributions such as Red Hat 9 and SuSE 8.2/9.x.   
   This distribution is optimised for Pentium 4
   but is fully compatible with all Intel Pentium 
   processors. 

   Newer versions of gcc (greater than 3.4), 
   by default, use libstdc++.so.6. Because the engine 
   links to libstdc++.so.5, there will be a general 
   warning about possible conflict. However, the
   compiled applications will work as expected.


2. Copy the downloaded file to the directory
   where you want to install it, then enter this
   command:

     tar -xf <package name> 

   Here, <package name> is the complete
   file name of the package you downloaded.
   Do not type the angled brackets. 
 

INSTALLING ON A MACINTOSH OS X SYSTEM

We distribute the engine and API files as a .tar
package that you can download from our web site 
and copy into your development area. 

To install the new files directly:

1. Download the appropriate distribution 
   package for your system: 

   Universal binary	smub6010.tar
  
2. Copy the downloaded file to the directory
   where you want to install it, then enter this
   command:

     tar -xf <package name> 

   Here, <package name> is the complete
   file name of the package you downloaded.
   Do not type the angled brackets. 
 
3. Copy the frameworks to the standard location:

   cp  -RP  *.framework  /Library/Frameworks/     


INSTALLING ON A MICROSOFT WINDOWS SYSTEM

We distribute the engine and API files as a .zip
package that you can download from our web site 
and copy into your development area.

To install the new files directly:

1. Download the following distribution package 
   into a temporary directory  on your computer: 

     swin6010.zip  for a 32-bit operating system
     sa646010.zip  for a 64-bit operating system
    
2. Unzip the package into its
   installation directory.


LIST OF FILES (UNIX)

In this release, we have not yet renamed files 
to reflect the change of engine version number.
We will change the UNIX major version number 
from 4 to 5 in a later release.

lib/config.dat           Engine configuration file
lib/libaixfv.a           Shared library, AIX only
lib/libbsdfv.so.4        Shared library, FreeBSD only
lib/libhpxfv.4           Shared library, HP-UX only
lib/liblnxfv.so.4        Shared library, Linux x86_32 & x86_64
lib/libsunfv.so.4        Shared library, Solaris SPARC & x86

include/avcodes.h        Parameter codes for the anti-virus engine
include/avengine.h       Function declarations
include/avmacro.h        Basic macros and definitions 
include/avparam.c        Functions for AV_PARAMETERS structure
include/avparam.h        Macros/function prototypes for AV_PARAMETERS structure
include/avtypes.h        Type definitions 
include/cpprt0_stub.s    Stub, HP-UX only 

examples/bldnotes.txt    Instructions for program examples 
examples/egx_v2.c        Program examples (V2 API)
examples/eg_update.c     Program example
examples/avstr.c          Safe string handling functions
examples/avstr.h          Safe string handling functions

dat/readme_dat.txt       DAT download information

doc/e6010apg.pdf         Product Guide  

contact.txt              Contact information 
license.txt              License information
readme.txt               This file
signlic.txt              Third-party license information


LIST OF FILES (MACINTOSH OS X)

lib/AVEngine.framework   Framework
lib/MacScanner.framework Framework for Macintosh-specific detection and repair  

include/avcodes.h        Parameter codes for anti-virus engine
include/avengine.h       Function declarations
include/avmacro.h        Basic macros and definitions   
include/avparam.c        Functions for AV_PARAMETERS structure 
include/avparam.h        Macros/function prototypes for AV_PARAMETERS structure
include/avtypes.h        Type definitions

examples/bldnotes.txt    Instructions for program examples
examples/egx_v2.c        Program examples (V2 API)
examples/eg_update.c     Program example
examples/avstr.c          Safe string handling functions
examples/avstr.h          Safe string handling functions

dat/readme_dat.txt       DAT download information

doc/e6010apg.pdf         Product Guide  
  
contact.txt              Contact information 
license.txt              License information    
readme.txt               This file       
signlic.txt              Third-party license information


LIST OF FILES (32-BIT MICROSOFT WINDOWS)

bin/config.dat           Engine configuration file
bin/mcscan32.dll         Anti-virus engine

include/avcodes.h        Parameter codes for anti-virus engine
include/avengine.h       Function declarations
include/avmacro.h        Basic macros and definitions   
include/avparam.c        Functions for AV_PARAMETERS structure
include/avparam.h        Macros/function prototypes for AV_PARAMETERS structure
include/avtypes.h        Type definitions

lib/mcscan32.lib         Link library for anti-virus engine

examples/bldnotes.txt    Instructions for program examples
examples/egX_v2.c        Program examples (V2 API)
examples/eg_update.c     Program example 
examples/avstr.c          Safe string handling functions
examples/avstr.h          Safe string handling functions

dat/readme_dat.txt       DAT download information

doc/e6010apg.pdf         Product Guide  

contact.txt              Contact information 
license.txt              License information
readme.txt               This file       
signlic.txt              Third-party license information


LIST OF FILES (64-BIT MICROSOFT WINDOWS)

bin/config.dat           Engine configuration file
bin/mcscan64a.dll        Anti-virus engine

include/avcodes.h        Parameter codes for anti-virus engine
include/avengine.h       Function declarations
include/avmacro.h        Basic macros and definitions   
include/avparam.c        Functions for AV_PARAMETERS structure
include/avparam.h        Macros/function prototypes for AV_PARAMETERS structure
include/avtypes.h        Type definitions

lib/mcscan64a.lib         Link library for anti-virus engine

examples/bldnotes.txt    Instructions for program examples
examples/egX_v2.c        Program examples (V2 API)
examples/eg_update.c     Program example 
examples/avstr.c          Safe string handling functions
examples/avstr.h          Safe string handling functions

dat/readme_dat.txt       DAT download information

doc/e6010apg.pdf         Product Guide  

contact.txt              Contact information 
license.txt              License information
readme.txt               This file       
signlic.txt              Third-party license information


_______________________________________________
KNOWN ISSUES
                                       
1. [UNIX enviroment] The Anti-Virus Engine might need a large 
   amount of data space. For maximum detection, we recommend
   setting your system's hard and soft data segment size limits 
   to unlimited", or as large as possible within the constraints 
   of your environment, in accordance with your OS vendor's 
   documentation.
   
2. [AIX environment] A change to the DAT files triggers a core 
   dump on AIX. This issue is addressed under the following KB 
   article:
   https://kb.mcafee.com/corporate/index?page=content&id=KB73380


________________________________________________
KNOWN LIMITATION

EOL Platform: 
- N/A for this release
________________________________________________
DOCUMENTATION

This product includes the following
documentation set:

-  Application Programming Interface Product Guide. 
   This guide is aimed at C programmers, and
   describes how to use the Application Programming 
   Interface to add anti-virus capabilities
   to third-party software. It describes the main 
   functions calls, plus internal structures,
   parameters, messages, and some useful macros.

-  A LICENSE Agreement. 
   The terms under which you may use the 
   product. Read it carefully. If you install 
   the product, you agree to the license terms.

-  Third-party license information.

-  This readme file. 

-  A bldnotes.txt file. 
   Explanations of the example programs in 
   the egx_v2.C files, and instructions on how 
   to build them.


__________________________________________________________
ENGINE END-OF-LIFE (EOL) PROGRAM

Your Anti-Virus software is only as good as its last
update!

Updating your DAT files and Anti-Virus Engine regularly
is essential and a MUST!

Sometimes architectural changes to the way that
the DAT files and Anti-Virus Engine work
together make it critical for you to update your
engine: an old engine WILL NOT catch some of today's
threats.

McAfee Labs recommends having as part of your
Security Policy Program, an Engine Update process to
take advantage of the latest technology and stay
protected!


THE PROBLEM

Around 500 new detections are added to the
DAT files daily by McAfee Labs. If you are not
up-to-date, you are vulnerable to any one of them
that gets a foothold in the field (also known as "in
the wild").

McAfee Labs releases regular DAT files,
ensuring that full protection is added to all McAfee
products. The DAT files contain the information
required to detect and remove threats - what to look
for and where to look for it.

However, today's threats are evolving almost on a
daily basis. Software providers continue to make
changes to operating systems and applications that
can change the way a program acts or works, and a
Anti-Virus program may not understand the
changes.


THE SOLUTION

Taking this into account, McAfee regularly
updates its Anti-Virus Engine used by ALL McAfee
virus-detection and removal products. The
engine understands all the different structures in
which a virus could lurk - EXE files, Microsoft
Office files, Linux files, and so on. Occasionally
these changes require us to make significant
architectural changes to the engine as well as the
DAT files.

McAfee Labs strongly recommends that users of ALL McAfee
Anti-Virus products update the engine in the 
products they have deployed as part of a
sound security best-practices program.

THE ENGINE END-OF-LIFE PROGRAM

To ensure protection from the evolving malicious code
threat, users should update as soon as possible upon
the release of McAfee's latest Anti-Virus Engine.

Engines begin their End of Life Process once a new
Engine version is released. Upon release of the new
engine version, the previous engine will be supported
for at most an additional 6 months, at the end of which
you will not be able to receive any further support on
the previous version.

Information on the McAfee Engine End-of-Life policy 
and a full list of supported engines and products 
can be found at:

       https://www.mcafee.com/enterprise/en-us/support/product-eol.html#product=scan_engine 


__________________________________________________________
PARTICIPATING IN THE MCAFEE BETA PROGRAM

To download new beta software or to read about the
latest beta information, visit the McAfee beta web
site located at:

		https://www.mcafee.com/enterprise/en-us/downloads/beta-programs.html

To submit beta feedback on any McAfee product, send
e-mail to:

       mcafee_beta@mcafee.com

McAfee is devoted to providing solutions based on
your input.


__________________________________________________________
CONTACT INFORMATION

THREAT CENTER:  McAfee Labs
    Homepage
       https://www.mcafee.com/enterprise/en-us/threat-center/mcafee-labs.html

    McAfee Labs Threat Library
       https://www.mcafee.com/enterprise/en-us/threat-center.html

    McAfee Labs DAT Notification Service
       https://sns.secure.mcafee.com/signup_login

DOWNLOAD SITE
    Homepage
       https://www.mcafee.com/enterprise/en-us/downloads.html

   -   Product Upgrades (Valid grant number
       required)
   -   Security Updates (DATs, engine)
   -   HotFix and Patch Releases
       -   For Security Vulnerabilities (Available
           to the public)
       -   For Products (ServicePortal account and
           valid grant number required)
   -   Product Evaluation
   -   McAfee Beta Program

TECHNICAL SUPPORT
    Homepage
        https://support.mcafee.com/

    KnowledgeBase Search
       https://kc.mcafee.com

    McAfee Technical Support ServicePortal (Logon
    credentials required)
       https://support.mcafee.com/ServicePortal

CUSTOMER SERVICE
   Web:       https://www.mcafee.com/enterprise/en-us/home/contact-us.html

   Phone:     +1-800-338-8754
              Monday-Friday, 8 a.m.-8 p.m., Central Time 
              US, Canada, and Latin America toll-free

PROFESSIONAL SERVICES
   -   Enterprise Business:
       https://www.mcafee.com/enterprise/en-us/home.html

_____________________________________________________
COPYRIGHT AND TRADEMARK ATTRIBUTIONS

Copyright � 2019 McAfee, LLC. All Rights Reserved.
No part of this publication may be reproduced,
transmitted, transcribed, stored in a retrieval
system, or translated into any language in any form
or�by�any means without the written permission of
McAfee, LLC., or its suppliers or affiliate
companies.


TRADEMARK ATTRIBUTIONS

McAfee and the McAfee logo, McAfee Active Protection, 
McAfee DeepSAFE, ePolicy Orchestrator, McAfee ePO, McAfee EMM, McAfee 
Evader, Foundscore, Foundstone, Global Threat Intelligence, McAfee LiveSafe, 
Policy Lab, McAfee QuickClean, Safe Eyes, McAfee SECURE, McAfee Shredder, SiteAdvisor, McAfee Stinger, McAfee TechMaster, McAfee Total Protection, 
TrustedSource, VirusScan are registered trademarks or trademarks of McAfee, Inc.
 or its subsidiaries in the US and other countries. Other marks and brands may be
 claimed as the property of others.


_____________________________________________________
LICENSE INFORMATION

LICENSE AGREEMENT

NOTICE TO ALL USERS: CAREFULLY READ THE APPROPRIATE
LEGAL AGREEMENT CORRESPONDING TO THE LICENSE YOU
PURCHASED, WHICH SETS FORTH THE GENERAL TERMS AND
CONDITIONS FOR THE USE OF THE LICENSED SOFTWARE. IF
YOU DO NOT KNOW WHICH TYPE OF LICENSE YOU HAVE
ACQUIRED, PLEASE CONSULT THE SALES AND OTHER RELATED
LICENSE GRANT OR PURCHASE ORDER DOCUMENTS THAT
ACCOMPANIES YOUR SOFTWARE PACKAGING OR THAT YOU HAVE
RECEIVED SEPARATELY AS PART OF THE PURCHASE (AS A
BOOKLET, A FILE ON THE PRODUCT CD, OR A FILE
AVAILABLE ON THE WEBSITE FROM WHICH YOU DOWNLOADED
THE SOFTWARE PACKAGE). IF YOU DO NOT AGREE TO ALL OF
THE TERMS SET FORTH IN THE AGREEMENT, DO NOT INSTALL
THE SOFTWARE. IF APPLICABLE, YOU MAY RETURN THE
PRODUCT TO MCAFEE OR THE PLACE OF PURCHASE FOR A
FULL REFUND.


LICENSE ATTRIBUTIONS

This product includes or may include:
* Software originally written by Philip Hazel,
Copyright (c) 1997-2008 University of Cambridge. A
copy of the license agreement for this software can
be found at www.pcre.org/license.txt *�This product 
includes software developed by the OpenSSL Project 
for use in the OpenSSL Toolkit (http://www.openssl.org/).
*�Cryptographic software written by Eric A. Young
and software written by Tim J. Hudson. *�Some
software programs that are licensed (or sublicensed)
to the user under the GNU General Public License
(GPL) or other similar Free Software licenses which,
among other rights, permit the user to copy, modify
and redistribute certain programs, or portions
thereof, and have access to the source code. The GPL
requires that for any software covered under the
GPL, which is distributed to someone in an
executable binary format, that the source code also
be made available to those users. For any such
software covered under the GPL, the source code is
made available on this CD. If any Free Software
licenses require that McAfee provide rights to use,
copy or modify a software program that are broader
than the rights granted in this agreement, then such
rights shall take precedence over the rights and
restrictions herein. *�Software originally written
by Henry Spencer, Copyright 1992, 1993, 1994, 1997
Henry Spencer. *�Software originally written by
Robert Nordier, Copyright (C) 1996-7 Robert Nordier.
*�Software written by Douglas W. Sauder. *�Software
developed by the Apache Software Foundation
(http://www.apache.org/). A copy of the license
agreement for this software can be found at
www.apache.org/licenses/LICENSE-2.0.txt.
*�International Components for Unicode ("ICU")
Copyright (C)�1995-2002 International Business
Machines Corporation and others. *�Software
developed by CrystalClear Software, Inc., Copyright
(C)�2000 CrystalClear Software, Inc. *�FEAD(R)
Optimizer(R) technology, Copyright Netopsystems AG,
Berlin, Germany. *�Outside In(R) Viewer Technology
(C)�1992-2001 Stellent Chicago, Inc. and/or Outside
In(R) HTML Export, (C) 2001 Stellent Chicago, Inc.
*�Software copyrighted by Thai Open Source Software
Center Ltd. and Clark Cooper, (C) 1998, 1999, 2000.
*�Software copyrighted by Expat maintainers.
*�Software copyrighted by The Regents of the
University of California, (C) 1996, 1989, 1998-2000.
*�Software copyrighted by Gunnar Ritter. *�Software
copyrighted by Sun Microsystems, Inc., 4150 Network
Circle, Santa Clara, California 95054, U.S.A., (C)
2003. *�Software copyrighted by Gisle Aas. (C)
1995-2003. *�Software copyrighted by Michael A.
Chase, (C) 1999-2000. *�Software copyrighted by Neil
Winton, (C)�1995-1996. *�Software copyrighted by RSA
Data Security, Inc., (C) 1990-1992. *�Software
copyrighted by Sean M. Burke, (C) 1999, 2000.
*�Software copyrighted by Martijn Koster, (C) 1995.
*�Software copyrighted by Brad Appleton, (C)
1996-1999.  *�Software copyrighted by Michael G.
Schwern, (C)�2001. *�Software copyrighted by Graham
Barr, (C) 1998. *�Software copyrighted by Larry Wall
and Clark Cooper, (C) 1998-2000. *�Software
copyrighted by Frodo Looijaard, (C) 1997. *�Software
copyrighted by the Python Software Foundation,
Copyright (C) 2001, 2002, 2003. A copy of the
license agreement for this software can be found at
www.python.org. *�Software copyrighted by Beman
Dawes, (C) 1994-1999, 2002. *�Software written by
Andrew Lumsdaine, Lie-Quan Lee, Jeremy G. Siek (C)
1997-2000 University of Notre Dame. *�Software
copyrighted by Simone Bordet & Marco Cravero, (C)
2002. *�Software copyrighted by Stephen Purcell, (C)
2001. *�Software developed by the Indiana University
Extreme! Lab (http://www.extreme.indiana.edu/).
*�Software copyrighted by International Business
Machines Corporation and others, (C) 1995-2003.
*�Software developed by the University of
California, Berkeley and its contributors.
*�Software developed by Ralf S. Engelschall
<rse@engelschall.com> for use in the mod_ssl project
(http://www.modssl.org/). *�Software copyrighted by
Kevlin Henney, (C) 2000-2002. *�Software copyrighted
by Peter Dimov and Multi Media Ltd. (C) 2001, 2002.
*�Software copyrighted by David Abrahams, (C) 2001,
2002. See http://www.boost.org/libs/bind/bind.html
for documentation. *�Software copyrighted by Steve
Cleary, Beman Dawes, Howard Hinnant & John Maddock,
(C) 2000. *�Software copyrighted by Boost.org, (C)
1999-2002. *�Software copyrighted by Nicolai M.
Josuttis, (C) 1999. *�Software copyrighted by Jeremy
Siek, (C) 1999-2001. *�Software copyrighted by
Daryle Walker, (C) 2001. *�Software copyrighted by
Chuck Allison and Jeremy Siek, (C) 2001, 2002.
*�Software copyrighted by Samuel Krempp, (C) 2001.
See http://www.boost.org for updates, documentation,
and revision history. *�Software copyrighted by Doug
Gregor (gregod@cs.rpi.edu), (C) 2001, 2002.
*�Software copyrighted by Cadenza New Zealand Ltd.,
(C) 2000. *�Software copyrighted by Jens Maurer,
(C)�2000, 2001. *�Software copyrighted by Jaakko
J�rvi (jaakko.jarvi@cs.utu.fi), (C)�1999, 2000.
*�Software copyrighted by Ronald Garcia, (C) 2002.
*�Software copyrighted by David Abrahams, Jeremy
Siek, and Daryle Walker, (C)�1999-2001. *�Software
copyrighted by Stephen Cleary (shammah@voyager.net),
(C)�2000. *�Software copyrighted by Housemarque Oy
<http://www.housemarque.com>, (C) 2001. *�Software
copyrighted by Paul Moore, (C) 1999. *�Software
copyrighted by Dr. John Maddock, (C) 1998-2002.
*�Software copyrighted by Greg Colvin and Beman
Dawes, (C) 1998, 1999. *�Software copyrighted by
Peter Dimov, (C) 2001, 2002. *�Software copyrighted
by Jeremy Siek and John R. Bandela, (C) 2001.
*�Software copyrighted by Joerg Walter and Mathias
Koch, (C) 2000-2002. *�Software copyrighted by
Carnegie Mellon University (C) 1989, 1991, 1992.
*�Software copyrighted by Cambridge Broadband Ltd.,
(C) 2001-2003. *�Software copyrighted by Sparta,
Inc., (C) 2003-2004. *�Software copyrighted by
Cisco, Inc and Information Network Center of Beijing
University of Posts and Telecommunications, (C)
2004. *�Software copyrighted by Simon Josefsson, (C)
2003. *�Software copyrighted by Thomas Jacob, (C)
2003-2004. *�Software copyrighted by Advanced
Software Engineering Limited, (C) 2004. *�Software
copyrighted by Todd C. Miller, (C) 1998. *�Software
copyrighted by The Regents of the University of
California, (C) 1990, 1993, with code derived from
software contributed to Berkeley by Chris Torek.
*Software copyrighted by Apache License Version 2.0, (c) 2018.
*Software copyrighted by The MIT License (c) 2018





DBN 017-EN 
RMID SDK
Deriv. V3.1.4 

