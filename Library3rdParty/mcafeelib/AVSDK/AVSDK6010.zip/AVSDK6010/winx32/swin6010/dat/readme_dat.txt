To update with the most recent DAT files, visit either

http://update.nai.com/Products/CommonUpdater

or

ftp://ftp.nai.com/CommonUpdater/ 

Download the full DATs which are available in a compressed form (.ZIP).
The file is named avvdat-XXXX.zip, where XXXX is the dat version.
For example, version 5586 will be named avvdat-5586.zip.

For more details of updating DAT files including incremental updating,
refer to the section "Updating your protection" in the API Guide.